@extends('layouts.app')
@section('content')
<div class="row">
   <div class="col-sm-12">
    <table id="example2" class="table table-bordered table-hover dataTable dtr-inline"
    aria-describedby="example2_info">
    <thead>
        <tr>
            <th class="sorting sorting_asc" tabindex="0" aria-controls="example2"
                rowspan="1" colspan="1" aria-sort="ascending"
                aria-label="Rendering engine: activate to sort column descending">
                {{ __('Cat_Name') }}</th>
            <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1"
                colspan="1" aria-label="Browser: activate to sort column ascending">
                {{ __('Cat_Description') }}</th>
            <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1"
                colspan="1"
                aria-label="Platform(s): activate to sort column ascending">{{ __('Action') }}
            </th>
            <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1"
                colspan="1"
                aria-label="Engine version: activate to sort column ascending">Engine
                version</th>
            <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1"
                colspan="1"
                aria-label="CSS grade: activate to sort column ascending">CSS grade</th>
        </tr>
    </thead>
    <tbody>

        <tr class="odd">
            <td class="dtr-control sorting_1" tabindex="0">Gecko</td>
            <td>Firefox 1.0</td>
            <td>Win 98+ / OSX.2+</td>
            <td>1.7</td>
            <td>A</td>
        </tr>
        <tr class="even">
            <td class="dtr-control sorting_1" tabindex="0">Gecko</td>
            <td>Firefox 1.5</td>
            <td>Win 98+ / OSX.2+</td>
            <td>1.8</td>
            <td>A</td>
        </tr>
        <tr class="odd">
            <td class="dtr-control sorting_1" tabindex="0">Gecko</td>
            <td>Firefox 2.0</td>
            <td>Win 98+ / OSX.2+</td>
            <td>1.8</td>
            <td>A</td>
        </tr>
        <tr class="even">
            <td class="dtr-control sorting_1" tabindex="0">Gecko</td>
            <td>Firefox 3.0</td>
            <td>Win 2k+ / OSX.3+</td>
            <td>1.9</td>
            <td>A</td>
        </tr>
        <tr class="odd">
            <td class="sorting_1 dtr-control">Gecko</td>
            <td>Camino 1.0</td>
            <td>OSX.2+</td>
            <td>1.8</td>
            <td>A</td>
        </tr>
        <tr class="even">
            <td class="sorting_1 dtr-control">Gecko</td>
            <td>Camino 1.5</td>
            <td>OSX.3+</td>
            <td>1.8</td>
            <td>A</td>
        </tr>
        <tr class="odd">
            <td class="sorting_1 dtr-control">Gecko</td>
            <td>Netscape 7.2</td>
            <td>Win 95+ / Mac OS 8.6-9.2</td>
            <td>1.7</td>
            <td>A</td>
        </tr>
        <tr class="even">
            <td class="sorting_1 dtr-control">Gecko</td>
            <td>Netscape Browser 8</td>
            <td>Win 98SE+</td>
            <td>1.7</td>
            <td>A</td>
        </tr>
        <tr class="odd">
            <td class="sorting_1 dtr-control">Gecko</td>
            <td>Netscape Navigator 9</td>
            <td>Win 98+ / OSX.2+</td>
            <td>1.8</td>
            <td>A</td>
        </tr>
        <tr class="even">
            <td class="sorting_1 dtr-control">Gecko</td>
            <td>Mozilla 1.0</td>
            <td>Win 95+ / OSX.1+</td>
            <td>1</td>
            <td>A</td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <th rowspan="1" colspan="1">Rendering engine</th>
            <th rowspan="1" colspan="1">Browser</th>
            <th rowspan="1" colspan="1">Platform(s)</th>
            <th rowspan="1" colspan="1">Engine version</th>
            <th rowspan="1" colspan="1">CSS grade</th>
        </tr>
    </tfoot>
</table>
   </div>
  </div>
@endsection