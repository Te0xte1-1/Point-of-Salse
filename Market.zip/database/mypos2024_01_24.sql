-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2024 at 02:08 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypos`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `account_type` int(11) DEFAULT NULL COMMENT 'نوع الحساب هل هو رأس مال ,عميل,مورد',
  `is_parent` tinyint(4) DEFAULT 0,
  `parrent_account_number` int(11) DEFAULT NULL COMMENT 'حساب الأب',
  `name` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL COMMENT 'رقم الحساب ويجب ان يكون مميز',
  `start_balance_status` varchar(50) DEFAULT NULL COMMENT 'حالة الحساب عند الإضافة هل هو متزن ام دائن ام مدين',
  `start_balance` decimal(10,2) DEFAULT 0.00 COMMENT 'رصيد الحساب اول المده',
  `current_balance` decimal(10,2) DEFAULT 0.00 COMMENT 'رصيد الحساب الحالي',
  `is_archived` tinyint(4) DEFAULT 0 COMMENT 'هل تمت أرشفته لان الحسابات المالية لا تحذف',
  `other_table_FK` int(11) DEFAULT NULL COMMENT 'جميع الحركات التي تأتي من الجداول الداخلية بيكون معاها  ',
  `com_code` int(11) DEFAULT NULL COMMENT 'كود الشركة',
  `notes` varchar(50) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='جدول الشجره المحاسبية';

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `account_type`, `is_parent`, `parrent_account_number`, `name`, `account_number`, `start_balance_status`, `start_balance`, `current_balance`, `is_archived`, `other_table_FK`, `com_code`, `notes`, `created_at`, `updated_at`, `added_by`, `updated_by`) VALUES
(1, 7, 1, NULL, 'حساب المصروفات', '1', '3', NULL, NULL, 1, NULL, NULL, 'لا توجد ملاحظات', '2024-01-11', '2024-01-11', NULL, NULL),
(2, 10, 1, NULL, 'الإيرادات', '2', '3', NULL, NULL, 1, NULL, NULL, 'لا توجد ملاحظات', '2024-01-11', '2024-01-11', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `accounts_type`
--

CREATE TABLE `accounts_type` (
  `id` int(11) NOT NULL,
  `account_name` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `related_internal_account` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='أنواع الحسابات المالية';

--
-- Dumping data for table `accounts_type`
--

INSERT INTO `accounts_type` (`id`, `account_name`, `status`, `related_internal_account`) VALUES
(1, 'رأس المال', 1, 0),
(2, 'مورد', 1, 0),
(3, 'عميل', 1, 0),
(4, 'مندوب', 1, NULL),
(5, 'موظف', 1, NULL),
(6, 'بنكي', 1, 0),
(7, 'مصروفات', 1, 0),
(8, 'قسم داخلي', 0, NULL),
(9, 'عام', 1, 0),
(10, 'الإيرادات', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `account tree`
--

CREATE TABLE `account tree` (
  `id` int(11) NOT NULL,
  `acc_serial` bigint(255) NOT NULL COMMENT 'رقم الحساب \r\nالأصول الثابته تبدا من الرقم 11000\r\nالأصول المتداوله تبدأ من الرقم 12000\r\n',
  `acc_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account tree`
--

INSERT INTO `account tree` (`id`, `acc_serial`, `acc_name`, `created_at`, `updated_at`) VALUES
(1, 10000, 'الأصول', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(2, 20000, 'الخصوم', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(3, 30000, 'حقوق الملكية', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(4, 40000, 'الإيرادات', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(5, 50000, 'المصروفات', '2024-01-14 19:39:29', '2024-01-14 19:39:29');

-- --------------------------------------------------------

--
-- Table structure for table `account_fourh`
--

CREATE TABLE `account_fourh` (
  `id` int(11) NOT NULL,
  `acc_third_id` int(11) NOT NULL,
  `acc_serial` bigint(255) NOT NULL COMMENT 'رقم الحساب \r\nالأصول الثابته تبدا من الرقم 11000\r\nالأصول المتداوله تبدأ من الرقم 12000\r\n',
  `acc_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `account_second`
--

CREATE TABLE `account_second` (
  `id` int(11) NOT NULL,
  `acc_one_id` int(11) NOT NULL,
  `acc_serial` bigint(255) NOT NULL COMMENT 'رقم الحساب \r\nالأصول الثابته تبدا من الرقم 11000\r\nالأصول المتداوله تبدأ من الرقم 12000\r\n',
  `acc_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_second`
--

INSERT INTO `account_second` (`id`, `acc_one_id`, `acc_serial`, `acc_name`, `created_at`, `updated_at`) VALUES
(1, 1, 11000, 'الأصول الثابتة', '2024-01-14 20:12:42', '2024-01-14 20:12:42'),
(2, 1, 12000, 'الأصول المتداولة', '2024-01-14 20:12:42', '2024-01-14 20:12:42'),
(3, 2, 21000, 'القروض والديون', '2024-01-14 20:21:03', '2024-01-14 20:21:03'),
(4, 2, 22000, 'الحسابات المدفوعه مقدما', '2024-01-14 20:21:03', '2024-01-14 20:21:03'),
(9, 3, 31000, 'رأس المال', '2024-01-14 20:22:26', '2024-01-14 20:22:26'),
(10, 4, 41000, 'المبيعات', '2024-01-14 20:22:26', '2024-01-14 20:22:26'),
(11, 4, 42000, 'الإيرادات الخرى', '2024-01-14 20:23:14', '2024-01-14 20:23:14'),
(12, 5, 51000, 'المصروفات العامة', '2024-01-14 20:23:14', '2024-01-14 20:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `account_third`
--

CREATE TABLE `account_third` (
  `id` int(11) NOT NULL,
  `acc_second_id` int(11) NOT NULL,
  `acc_serial` bigint(255) NOT NULL COMMENT 'رقم الحساب \r\nالأصول الثابته تبدا من الرقم 11000\r\nالأصول المتداوله تبدأ من الرقم 12000\r\n',
  `acc_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(191) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins_shifts`
--

CREATE TABLE `admins_shifts` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `treasures_id` int(11) DEFAULT NULL,
  `delevered_to_admin_shift` int(11) DEFAULT NULL COMMENT 'الشفت الذي سيستلم',
  `delevered_to_admin_treasures` int(11) DEFAULT NULL COMMENT 'الخزنه التي سوف تستلم',
  `money_started_balanced` int(11) DEFAULT 0 COMMENT 'المبلغ الموجود في الخزينة حالة بدأ الشفت',
  `started_date` int(11) DEFAULT NULL COMMENT 'وقت بدأ الشفت',
  `end_date` int(11) DEFAULT NULL COMMENT 'وقت انتهاء الشفت',
  `is_finished` int(11) DEFAULT 0 COMMENT 'هل انتهى الشفت',
  `is_delevered_and_reviewed` int(11) DEFAULT NULL COMMENT 'هل تم التسليم والمراجعه للخزنة والشفت',
  `delevered_and_reviewed_data` date DEFAULT NULL COMMENT 'تاريخ مراجعه ',
  `money_should_delevered` int(11) DEFAULT NULL COMMENT 'المبلغ الفعلي الذي يجب تسلمه',
  `money_real_pay` int(11) DEFAULT NULL COMMENT 'المبلغ الفعلي الذي تم تسلمه',
  `money_state` int(11) DEFAULT NULL COMMENT '0- balanced 1- inabileite 2- extra',
  `money_state_value` int(11) DEFAULT NULL COMMENT 'قيمة العجز او الزيادة ان وجدت',
  `recive_type` int(11) DEFAULT NULL COMMENT '1- استلام على نفس الخزنة\r\n2- استلام من خزنة اخرى\r\n',
  `treasures_transaction_id` int(11) DEFAULT NULL COMMENT 'رقم الإيصال بجدول تحصيل النقدية لحركة الخزن',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins_treasures`
--

CREATE TABLE `admins_treasures` (
  `id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `treasures_id` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='صلاحيات خزن المستخدمين الخاصة\r\nاضافة خزن للمستخدمين';

-- --------------------------------------------------------

--
-- Table structure for table `bill_type`
--

CREATE TABLE `bill_type` (
  `id` int(11) NOT NULL,
  `bill_type_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill_type`
--

INSERT INTO `bill_type` (`id`, `bill_type_name`) VALUES
(1, 'فاتورة مبيعات مبدئية\r\n'),
(2, 'فاتورة مشتريات مبدئية\r\n'),
(3, 'فاتورة مبيعات'),
(4, 'فاتورة  مشتريات'),
(5, 'فاتورة  مردود مبيعات'),
(6, 'فاتورة  مردود فاتورة  مردود مشتريات'),
(7, 'بضاعه أول مدة');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_name` varchar(191) NOT NULL,
  `cat_description` varchar(191) DEFAULT NULL,
  `status` tinyint(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cat_name`, `cat_description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'قسم الملابس الداخلية', 'ملابس داخلية عام', 1, '2024-01-12 11:08:59', '2024-01-12 11:15:57'),
(2, 'قسم الملابس الرجالية', 'ملابس داخلية للرجال فقط', 1, '2024-01-12 11:10:48', '2024-01-12 19:47:03'),
(3, 'قسم الملابس النسائية', NULL, 1, '2024-01-12 11:14:01', '2024-01-12 11:14:01'),
(4, 'قسم الملابس الأطفالي', NULL, 1, '2024-01-12 11:14:58', '2024-01-12 11:14:58');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `account_number` int(11) DEFAULT NULL,
  `customer_name` varchar(191) NOT NULL,
  `start_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `current_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `customer_address` varchar(191) DEFAULT NULL,
  `customer_phone` varchar(191) DEFAULT NULL,
  `customer_email` varchar(191) DEFAULT NULL,
  `customer_imge` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `account_number`, `customer_name`, `start_balance`, `current_balance`, `customer_address`, `customer_phone`, `customer_email`, `customer_imge`, `created_at`, `updated_at`) VALUES
(1, 21000150, 'moahmed yousif', '10.00', '10.00', 'cairo', NULL, 'test@hotmail.com', '[000047].png', '2024-01-12 22:25:21', '2024-01-12 22:25:21'),
(2, 1210002, 'nasr alden osman', '0.00', '4000.00', 'oumdurman', NULL, 'test@test.com', 'received_817665913211273.jpeg', '2024-01-14 18:32:09', '2024-01-14 18:32:09');

-- --------------------------------------------------------

--
-- Table structure for table `first_inserts`
--

CREATE TABLE `first_inserts` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `pro_id` int(11) DEFAULT NULL,
  `stock_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `qty` decimal(10,2) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_cost` decimal(10,2) DEFAULT NULL,
  `salse_price` int(11) DEFAULT NULL,
  `has_production_date` tinyint(4) DEFAULT NULL,
  `creation_product` date DEFAULT NULL,
  `expiration_product` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='جدول بضاعة أول المده';

-- --------------------------------------------------------

--
-- Table structure for table `inv_itemcart_movments`
--

CREATE TABLE `inv_itemcart_movments` (
  `id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `item_code` bigint(20) NOT NULL,
  `items_movments_types` int(11) NOT NULL,
  `FK_table` bigint(20) NOT NULL,
  `FK_table_detailse` bigint(20) NOT NULL,
  `byan` varchar(255) NOT NULL,
  `qty_before_movement` varchar(255) NOT NULL,
  `qty_after_movement` varchar(255) NOT NULL,
  `added_by` int(11) NOT NULL,
  `date` date NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inv_itemcart_movment_types`
--

CREATE TABLE `inv_itemcart_movment_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='أنواع الحركات إما أن تكون مشتريات او مبيعات او مخازن';

--
-- Dumping data for table `inv_itemcart_movment_types`
--

INSERT INTO `inv_itemcart_movment_types` (`id`, `name`) VALUES
(1, 'مشتريات'),
(2, 'مرتجع مشتريات'),
(3, 'مبيعات'),
(4, 'مرتجع مبيعات'),
(5, 'تحويل بين المخازن');

-- --------------------------------------------------------

--
-- Table structure for table `inv_item_movment_category`
--

CREATE TABLE `inv_item_movment_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='فئات الحركات تندرج تحتها انواع الحركات ';

--
-- Dumping data for table `inv_item_movment_category`
--

INSERT INTO `inv_item_movment_category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'حركه على المشتريات', NULL, NULL),
(2, 'حركه على المبيعات', NULL, NULL),
(3, 'حركه على المخازن', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mony_move_type`
--

CREATE TABLE `mony_move_type` (
  `id` int(11) NOT NULL,
  `mony_move_type` varchar(50) DEFAULT NULL,
  `screen_show` varchar(50) DEFAULT NULL,
  `move_type` int(11) DEFAULT NULL COMMENT 'نوع الحركة هل هي صرف ام تحصيل\r\n-صرف = 1\r\nنحصيل = 2',
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='انواع الحركات المالية';

--
-- Dumping data for table `mony_move_type`
--

INSERT INTO `mony_move_type` (`id`, `mony_move_type`, `screen_show`, `move_type`, `status`) VALUES
(1, ' مراجعة واستلام نقدية شفت على نفس الخزينة', 'بشاشة التحصيل', 2, 0),
(2, 'مراجعة واستلام نقدية شفت خزنة اخرى', 'بشاشة التحصيل', 2, 0),
(3, 'صرف مبلغ لحساب مالي', 'بشاشة الصرف', 1, 0),
(4, 'تحصيل مبلغ من حساب مالي', 'بشاشة التحصيل', 2, 0),
(5, 'تحصيل ايراد مبيعات', 'بشاشة التحصيل', 2, 0),
(6, 'صرف نظير مرتجع مبيعات', 'بشاشة الصرف', 1, 0),
(7, 'صرف نظير مشتريات من مورد', 'بشاشة الصرف', 1, 0),
(8, 'تحصيل نظير مرتجع مشتريات الى مورد', 'بشاشة التحصيل', 2, 0),
(9, 'ايراد زيادة رأس المال', 'بشاشة التحصيل', 2, 0),
(10, 'مصاريف عامة', 'بشاشة الصرف', 1, 1),
(11, 'صرف للإيداع البنكي', 'بشاشة الصرف', 1, 0),
(12, 'سحب من البنك', 'بشاشة التحصيل', 2, 0),
(13, 'صرف لرد رأس المال', 'بشاشة الصرف', 1, 0),
(23, 'بضاعة أول المدة', 'بشاشه الصرف', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(191) NOT NULL,
  `customer_email` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pay_type`
--

CREATE TABLE `pay_type` (
  `id` int(11) NOT NULL,
  `pay_type_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pay_type`
--

INSERT INTO `pay_type` (`id`, `pay_type_name`) VALUES
(1, 'كاش'),
(2, 'أجل'),
(3, 'جزء أجل و جزء كاش');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `product_serial` varchar(255) DEFAULT NULL,
  `product_name` varchar(191) NOT NULL,
  `product_description` varchar(191) DEFAULT NULL,
  `purshace_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `does_has_unit` tinyint(4) NOT NULL DEFAULT 0 COMMENT 'هل للصنف وحدة تجزئة',
  `unit_id` int(11) NOT NULL DEFAULT 0 COMMENT 'كود وحدة قياس الأب',
  `retail_uom_qty_to_parent` int(11) NOT NULL DEFAULT 0 COMMENT 'كم حبة في الوحدة',
  `risk` int(11) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `move_type` int(11) DEFAULT NULL,
  `creation_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `product_serial`, `product_name`, `product_description`, `purshace_price`, `price`, `stock`, `does_has_unit`, `unit_id`, `retail_uom_qty_to_parent`, `risk`, `photo`, `move_type`, `creation_date`, `expiration_date`, `created_at`, `updated_at`) VALUES
(1, 1, '10001', 'T-shirt white', 'Just Tishert', 150, 200, 100, 0, 200, 0, 10, '17050793638543.png', NULL, '2024-01-17', '2024-02-17', '2024-01-12 15:09:23', '2024-01-17 19:04:25'),
(2, 4, '40002', 'New Baby Clothes', 'nothing', 10000, 2000, 100, 0, 2000, 0, 10, '17052644946526.jpeg', NULL, '2024-01-17', '2024-03-17', '2024-01-14 18:34:54', '2024-01-17 19:05:05'),
(3, 2, '20003', 'T-shirt-For Main', 'nothing at all', 150, 456, 100, 0, 0, 0, 10, '1705449023254.bmp', NULL, NULL, NULL, '2024-01-16 21:50:23', '2024-01-16 21:50:23'),
(4, 2, '20004', 'T-shirt-For Main', 'nothing at all', 150, 32, 100, 0, 0, 0, 10, '17054490881802.bmp', NULL, NULL, NULL, '2024-01-16 21:51:28', '2024-01-16 21:51:28'),
(5, 2, '20005', 'New T-shirt-For Main', 'nothing at all', 150, 960, 100, 0, 0, 0, 10, '17054492629638.bmp', NULL, NULL, NULL, '2024-01-16 21:54:22', '2024-01-16 21:54:22'),
(6, 2, '20006', 'House New T-shirt-For Main', 'nothing at all', 150, 150, 100, 0, 0, 0, 10, '170544931132.bmp', NULL, NULL, NULL, '2024-01-16 21:55:11', '2024-01-16 21:55:11'),
(7, 4, '40007', 'baby hair clusies', 'new bala', 500, 43, 100, 0, 0, 0, 50, '17054494103804.png', NULL, NULL, NULL, '2024-01-16 21:56:50', '2024-01-16 21:56:51'),
(8, 1, '10008', 'ملابس داخلية رقم الف', 'تستس', 900, 1500, 30, 0, 0, 0, 10, '17054494706768.jpg', NULL, NULL, NULL, '2024-01-16 21:57:50', '2024-01-16 21:57:50'),
(9, 1, '10009', '45', '5454', 54, 545, 454, 0, 0, 0, 54, '1705449521112.png', NULL, NULL, NULL, '2024-01-16 21:58:41', '2024-01-16 21:58:41'),
(10, 1, '100010', 'ملابس ؤردية', 'وردي', 600, 785, 454, 0, 0, 0, 54, '17054496504291.jpg', NULL, NULL, NULL, '2024-01-16 22:00:50', '2024-01-16 22:00:51');

-- --------------------------------------------------------

--
-- Table structure for table `product_with_store`
--

CREATE TABLE `product_with_store` (
  `id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT NULL COMMENT 'كود المخزن',
  `pro_id` int(11) DEFAULT NULL COMMENT 'كود المنتج',
  `unit_id` int(11) DEFAULT NULL COMMENT 'وحدة قياس التجزئة',
  `unit_cost_price` int(11) DEFAULT NULL COMMENT 'سعر الشراء للوحدة',
  `qty_of_unit` int(11) DEFAULT NULL COMMENT 'الكمية بالوحدة',
  `total_cost_price` int(11) DEFAULT NULL COMMENT 'إجمالي سعر شراء الباتش ككل',
  `production_date` int(11) DEFAULT NULL,
  `expire_date` int(11) DEFAULT NULL,
  `auto_serial` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `salse`
--

CREATE TABLE `salse` (
  `id` int(11) NOT NULL,
  `account_number` int(11) DEFAULT 0,
  `serial` varchar(191) DEFAULT NULL,
  `is_approved` tinyint(4) DEFAULT 0,
  `approved_by` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT 0 COMMENT 'العميل 0 يعني انه ليس لديه حساب في النظام',
  `bill_type` int(11) DEFAULT NULL,
  `pay_type` int(11) DEFAULT NULL,
  `what_paid` int(11) DEFAULT NULL,
  `what_not_yet_paid` int(11) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  `treasures_id` int(11) DEFAULT NULL,
  `total_item_count` int(11) DEFAULT NULL COMMENT 'العدد الكلي للأصناف في الفاتورة',
  `date` date DEFAULT curdate(),
  `created_at` timestamp NULL DEFAULT curdate(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `salse_detailse`
--

CREATE TABLE `salse_detailse` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `salse_id` int(20) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `qty` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `created_at` date DEFAULT curdate(),
  `updated_at` date DEFAULT NULL,
  `move_type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_company`
--

CREATE TABLE `settings_company` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(191) NOT NULL,
  `company_logo` varchar(191) NOT NULL,
  `company_address` varchar(191) NOT NULL,
  `company_phone` varchar(191) NOT NULL,
  `company_description` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stock_name` varchar(50) NOT NULL DEFAULT '',
  `stock_qty` int(11) DEFAULT NULL,
  `stock_location` varchar(50) DEFAULT NULL,
  `created_at` date DEFAULT current_timestamp(),
  `updated_at` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `stock_name`, `stock_qty`, `stock_location`, `created_at`, `updated_at`) VALUES
(1, 'المعرض', NULL, NULL, NULL, '2023-08-02'),
(2, 'المخزن الرئيسي', NULL, NULL, NULL, '2023-08-02'),
(3, 'المخزن الفرعي', NULL, NULL, NULL, '2023-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `stock_data`
--

CREATE TABLE `stock_data` (
  `id` int(11) NOT NULL,
  `auto_serial` varchar(255) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `cat_id` int(10) UNSIGNED DEFAULT NULL,
  `pro_id` int(10) UNSIGNED DEFAULT NULL,
  `unit_id` int(10) UNSIGNED DEFAULT NULL,
  `unit_cost_price` decimal(10,2) UNSIGNED DEFAULT NULL,
  `qty` decimal(10,2) UNSIGNED DEFAULT NULL,
  `total_cost_unit` decimal(10,2) UNSIGNED DEFAULT NULL,
  `risk` int(11) DEFAULT 10,
  `bill_type` bigint(20) UNSIGNED DEFAULT NULL,
  `move_type` bigint(20) UNSIGNED DEFAULT NULL,
  `production_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `sup_name` varchar(155) NOT NULL,
  `start_balance` decimal(10,2) DEFAULT NULL,
  `current_balance` decimal(10,2) DEFAULT NULL,
  `sup_address` varchar(155) DEFAULT NULL,
  `sup_phone` varchar(155) DEFAULT NULL,
  `sup_email` varchar(150) DEFAULT NULL,
  `sup_image` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `account_number`, `sup_name`, `start_balance`, `current_balance`, `sup_address`, `sup_phone`, `sup_email`, `sup_image`, `created_at`, `updated_at`) VALUES
(1, '0001', 'ahmed Osman Hamza', '0.00', '0.00', 'أمدرمان', NULL, 'test@hotmail.com', NULL, '2024-01-12', '2024-01-17'),
(2, NULL, 'mohamed Yousif', '500.00', '1500.00', 'أمبدة السبيل', NULL, 'test@test.com', 'تجريبي.jpg', '2024-01-13', '2024-01-13');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_with_order`
--

CREATE TABLE `supplier_with_order` (
  `id` int(11) NOT NULL,
  `auto_serial` int(11) DEFAULT NULL,
  `is_approved` tinyint(4) DEFAULT 0 COMMENT 'هل تم اعتماد الفاتورة\r\n',
  `approved_by` int(11) DEFAULT NULL,
  `bill_type` tinyint(4) DEFAULT NULL COMMENT 'نوع الفاتورة هل هي\r\n1- فاتورة مشتريات\r\n2- فاتورة مرتجع مشتريات على نفس الفاتورة\r\n3- هل هي مرتجع عام بترجع بدون تقيد بأصل الفاتورة',
  `order_pay_type` int(11) DEFAULT NULL,
  `order_date` date DEFAULT curdate(),
  `supplier_id` int(11) DEFAULT 0 COMMENT 'العميل 0 يعني انه ليس لديه حساب في النظام',
  `account_number` int(11) DEFAULT NULL,
  `total_cost` decimal(10,0) DEFAULT 0,
  `money_for_account` decimal(10,0) DEFAULT 0,
  `what_paid` decimal(10,0) DEFAULT 0,
  `what_remain` decimal(10,0) DEFAULT 0,
  `treasures_transaction_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL COMMENT 'كود المخزن',
  `treasures_id` int(11) DEFAULT NULL,
  `supplier_balance_before` decimal(10,0) DEFAULT 0 COMMENT 'حاله رصيد المورد قبل الفاتورة',
  `supplier_balance_fater` decimal(10,0) DEFAULT NULL COMMENT 'حاله رصيد المورد بعد الفاتورة',
  `note` varchar(50) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='جدول مشتريات ومرتجعات الموردين';

--
-- Dumping data for table `supplier_with_order`
--

INSERT INTO `supplier_with_order` (`id`, `auto_serial`, `is_approved`, `approved_by`, `bill_type`, `order_pay_type`, `order_date`, `supplier_id`, `account_number`, `total_cost`, `money_for_account`, `what_paid`, `what_remain`, `treasures_transaction_id`, `store_id`, `treasures_id`, `supplier_balance_before`, `supplier_balance_fater`, `note`, `created_at`, `updated_at`) VALUES
(3, 68038304, 1, NULL, 4, 1, '2024-01-23', 0, NULL, '33300', '0', '33300', '0', NULL, 1, 1, '0', NULL, 'لا توجد ملاحظات', '2024-01-23', '2024-01-24'),
(4, 68038306, 1, NULL, 4, 1, '2024-01-23', 0, NULL, '15000', '0', '15000', '0', NULL, 1, 1, '0', NULL, 'لا توجد ملاحظات', '2024-01-23', '2024-01-23'),
(5, 631132208, 1, NULL, 4, 1, '2024-01-24', 2, NULL, '11040', '0', '11040', '0', NULL, 8, 2, '0', NULL, 'لا توجد ملاحظات', '2024-01-24', '2024-01-24');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_with_order_detailse`
--

CREATE TABLE `supplier_with_order_detailse` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `item_qty` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` int(11) DEFAULT NULL COMMENT 'سعر الوحدة',
  `total_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الوحدة ضرب الكمية',
  `creation_product` date DEFAULT NULL,
  `expiration_product` date DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL COMMENT 'رقم الباتش في المخزن الذي تم التخزين الصنف بها',
  `created_at` date DEFAULT current_timestamp(),
  `updated_at` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='تفاصيل أصناف فاتورة المشتريات والمرتجعات';

--
-- Dumping data for table `supplier_with_order_detailse`
--

INSERT INTO `supplier_with_order_detailse` (`id`, `order_id`, `cat_id`, `item_id`, `item_qty`, `unit_id`, `unit_price`, `total_price`, `creation_product`, `expiration_product`, `batch_id`, `created_at`, `updated_at`) VALUES
(1, 68038306, 1, 8, 100, 1, 150, '15000.00', '2024-01-23', '2024-02-23', NULL, '2024-01-23', '2024-01-23'),
(2, 68038304, 1, 8, 50, 1, 300, '15000.00', NULL, NULL, NULL, '2024-01-24', '2024-01-24'),
(3, 68038304, 4, 2, 63, 1, 100, '6300.00', NULL, NULL, NULL, '2024-01-24', '2024-01-24'),
(4, 68038304, 2, 5, 48, 1, 250, '12000.00', NULL, NULL, NULL, '2024-01-24', '2024-01-24'),
(5, 631132208, 2, 3, 230, 1, 48, '11040.00', '2024-01-24', '2024-02-02', NULL, '2024-01-24', '2024-01-24');

-- --------------------------------------------------------

--
-- Table structure for table `treasures`
--

CREATE TABLE `treasures` (
  `id` int(11) NOT NULL,
  `treasures_serial` varchar(255) DEFAULT NULL,
  `treasures_name` varchar(155) NOT NULL,
  `is_master` tinyint(4) DEFAULT 0,
  `last_isal_exchange` bigint(20) DEFAULT NULL,
  `last_isal_collect` bigint(20) DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `treasures`
--

INSERT INTO `treasures` (`id`, `treasures_serial`, `treasures_name`, `is_master`, `last_isal_exchange`, `last_isal_collect`, `active`, `created_at`, `updated_at`) VALUES
(1, '10-T', 'الخزنة الرئيسية', 1, 9, 2, 1, '2024-01-11 04:25:36', '2024-01-24 04:50:02'),
(2, NULL, 'الخزنة الفرعية', 0, NULL, 1, 0, '2024-01-13 14:28:01', '2024-01-24 04:58:01');

-- --------------------------------------------------------

--
-- Table structure for table `treasures_delevry`
--

CREATE TABLE `treasures_delevry` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `treasures_transactions`
--

CREATE TABLE `treasures_transactions` (
  `id` int(11) NOT NULL,
  `isal_number` int(11) DEFAULT NULL COMMENT 'كود العملية',
  `shift_code` int(11) DEFAULT NULL COMMENT 'كود الشفت للمستخدم',
  `treasures_id` int(11) DEFAULT NULL,
  `is_account` int(11) DEFAULT NULL COMMENT 'هل هو حساب مالي',
  `account_type` bigint(20) DEFAULT NULL COMMENT 'نوع الحساب هل هو رأس مال ام عميل ام مورد او غيرة',
  `account_number` bigint(20) DEFAULT NULL COMMENT 'رقم الحساب المالي',
  `money` int(11) DEFAULT NULL COMMENT 'قيمة المبلغ المتحصل او المصروف بالخزنة',
  `money_for_account` int(11) DEFAULT NULL COMMENT 'قيمة المبلغ المستحق او المخصوم من الحساب المالي',
  `foreign_key` bigint(20) DEFAULT NULL COMMENT 'كود الجدول الأخر المرتبط بالحركة',
  `move_type_id` bigint(20) DEFAULT NULL COMMENT 'نوع الحركة النقدية',
  `note` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='جدول حركة النقدية\r\nبالشفتات\r\nكل العمليات المالية بتصب فيه \r\nلازم كل العمليات تسمع عليه';

--
-- Dumping data for table `treasures_transactions`
--

INSERT INTO `treasures_transactions` (`id`, `isal_number`, `shift_code`, `treasures_id`, `is_account`, `account_type`, `account_number`, `money`, `money_for_account`, `foreign_key`, `move_type_id`, `note`, `date`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 1, NULL, NULL, -200, 200, NULL, NULL, NULL, NULL, NULL, '2024-01-13 22:22:56', '2024-01-13 22:22:56'),
(2, 2, 1, 1, 1, NULL, NULL, -2200, 2200, NULL, NULL, NULL, NULL, NULL, '2024-01-15 20:10:49', '2024-01-15 20:10:49'),
(3, 3, 1, 1, 1, NULL, NULL, -200, 200, NULL, NULL, NULL, NULL, NULL, '2024-01-15 20:12:38', '2024-01-15 20:12:38'),
(4, 4, 1, 1, 1, NULL, NULL, -200, 200, NULL, NULL, NULL, NULL, NULL, '2024-01-15 22:54:42', '2024-01-15 22:54:42'),
(5, 5, 1, 1, 1, NULL, NULL, -7000, 7000, NULL, NULL, NULL, NULL, NULL, '2024-01-15 22:56:37', '2024-01-15 22:56:37'),
(6, 6, 1, 1, 1, NULL, NULL, -7000, 7000, NULL, NULL, NULL, NULL, NULL, '2024-01-15 22:57:30', '2024-01-15 22:57:30'),
(7, 7, 1, 1, 1, NULL, NULL, -7000, 7000, NULL, NULL, NULL, NULL, NULL, '2024-01-15 22:58:49', '2024-01-15 22:58:49'),
(8, 8, 1, 1, 1, NULL, NULL, -7000, 7000, NULL, NULL, NULL, NULL, NULL, '2024-01-15 22:59:23', '2024-01-15 22:59:23'),
(9, 9, 1, 1, 1, NULL, NULL, -200, 200, NULL, NULL, NULL, NULL, NULL, '2024-01-18 09:59:50', '2024-01-18 09:59:50'),
(10, 1, 1, 1, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '2024-01-23 12:23:32', '2024-01-23 12:23:32'),
(11, 2, 1, 1, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '2024-01-24 04:50:02', '2024-01-24 04:50:02'),
(12, 1, 1, 2, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '2024-01-24 04:58:01', '2024-01-24 04:58:01');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unit_name` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `unit_name`, `created_at`, `updated_at`) VALUES
(1, 'كيلو', '2024-01-12 20:59:54', '2024-01-12 20:59:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `username` varchar(150) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_type` (`account_type`);

--
-- Indexes for table `accounts_type`
--
ALTER TABLE `accounts_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account tree`
--
ALTER TABLE `account tree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_fourh`
--
ALTER TABLE `account_fourh`
  ADD PRIMARY KEY (`id`),
  ADD KEY `acc_one` (`acc_third_id`);

--
-- Indexes for table `account_second`
--
ALTER TABLE `account_second`
  ADD PRIMARY KEY (`id`),
  ADD KEY `acc_one` (`acc_one_id`);

--
-- Indexes for table `account_third`
--
ALTER TABLE `account_third`
  ADD PRIMARY KEY (`id`),
  ADD KEY `acc_one` (`acc_second_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins_shifts`
--
ALTER TABLE `admins_shifts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill_type`
--
ALTER TABLE `bill_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `first_inserts`
--
ALTER TABLE `first_inserts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_itemcart_movments`
--
ALTER TABLE `inv_itemcart_movments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_itemcart_movment_types`
--
ALTER TABLE `inv_itemcart_movment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_item_movment_category`
--
ALTER TABLE `inv_item_movment_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mony_move_type`
--
ALTER TABLE `mony_move_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_type`
--
ALTER TABLE `pay_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `product_with_store`
--
ALTER TABLE `product_with_store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salse`
--
ALTER TABLE `salse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salse_detailse`
--
ALTER TABLE `salse_detailse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salse_id` (`salse_id`);

--
-- Indexes for table `settings_company`
--
ALTER TABLE `settings_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_data`
--
ALTER TABLE `stock_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_with_order`
--
ALTER TABLE `supplier_with_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_with_order_detailse`
--
ALTER TABLE `supplier_with_order_detailse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treasures`
--
ALTER TABLE `treasures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treasures_transactions`
--
ALTER TABLE `treasures_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `account tree`
--
ALTER TABLE `account tree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `account_fourh`
--
ALTER TABLE `account_fourh`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `account_second`
--
ALTER TABLE `account_second`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `account_third`
--
ALTER TABLE `account_third`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins_shifts`
--
ALTER TABLE `admins_shifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bill_type`
--
ALTER TABLE `bill_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `first_inserts`
--
ALTER TABLE `first_inserts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inv_itemcart_movments`
--
ALTER TABLE `inv_itemcart_movments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inv_itemcart_movment_types`
--
ALTER TABLE `inv_itemcart_movment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `inv_item_movment_category`
--
ALTER TABLE `inv_item_movment_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mony_move_type`
--
ALTER TABLE `mony_move_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_type`
--
ALTER TABLE `pay_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product_with_store`
--
ALTER TABLE `product_with_store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salse`
--
ALTER TABLE `salse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salse_detailse`
--
ALTER TABLE `salse_detailse`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings_company`
--
ALTER TABLE `settings_company`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stock_data`
--
ALTER TABLE `stock_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `supplier_with_order`
--
ALTER TABLE `supplier_with_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `supplier_with_order_detailse`
--
ALTER TABLE `supplier_with_order_detailse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `treasures`
--
ALTER TABLE `treasures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `treasures_transactions`
--
ALTER TABLE `treasures_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `account_type` FOREIGN KEY (`account_type`) REFERENCES `accounts_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `account_fourh`
--
ALTER TABLE `account_fourh`
  ADD CONSTRAINT `acc_third` FOREIGN KEY (`acc_third_id`) REFERENCES `account_second` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `account_second`
--
ALTER TABLE `account_second`
  ADD CONSTRAINT `acc_one` FOREIGN KEY (`acc_one_id`) REFERENCES `account tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `account_third`
--
ALTER TABLE `account_third`
  ADD CONSTRAINT `acc_second` FOREIGN KEY (`acc_second_id`) REFERENCES `account_second` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `salse_detailse`
--
ALTER TABLE `salse_detailse`
  ADD CONSTRAINT `salse_id` FOREIGN KEY (`salse_id`) REFERENCES `salse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
