-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2024 at 11:17 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypos`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `account_type` int(11) DEFAULT NULL COMMENT 'نوع الحساب هل هو رأس مال ,عميل,مورد',
  `is_parent` tinyint(4) DEFAULT 0,
  `parrent_account_number` int(11) DEFAULT NULL COMMENT 'حساب الأب',
  `name` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL COMMENT 'رقم الحساب ويجب ان يكون مميز',
  `start_balance_status` varchar(50) DEFAULT NULL COMMENT 'حالة الحساب عند الإضافة هل هو متزن ام دائن ام مدين',
  `start_balance` decimal(10,2) DEFAULT 0.00 COMMENT 'رصيد الحساب اول المده',
  `current_balance` decimal(10,2) DEFAULT 0.00 COMMENT 'رصيد الحساب الحالي',
  `is_archived` tinyint(4) DEFAULT 0 COMMENT 'هل تمت أرشفته لان الحسابات المالية لا تحذف',
  `photo` varchar(255) DEFAULT NULL,
  `other_table_FK` int(11) DEFAULT NULL COMMENT 'جميع الحركات التي تأتي من الجداول الداخلية بيكون معاها  ',
  `com_code` int(11) DEFAULT NULL COMMENT 'كود الشركة',
  `notes` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='جدول الشجره المحاسبية';

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `account_type`, `is_parent`, `parrent_account_number`, `name`, `account_number`, `start_balance_status`, `start_balance`, `current_balance`, `is_archived`, `photo`, `other_table_FK`, `com_code`, `notes`, `date`, `created_at`, `updated_at`, `added_by`, `updated_by`) VALUES
(1, 2, 0, 2, 'نصرالدين عثمان', '1212001', NULL, '0.00', '0.00', 1, NULL, NULL, NULL, 'لا توجد ملاحظات', '2024-02-19', '2024-02-19', '2024-03-08', NULL, NULL),
(2, 3, 0, 3, 'محمد عثمان', '1211001', NULL, '0.00', '0.00', 1, NULL, NULL, NULL, 'لا توجد ملاحظات', '2024-02-19', '2024-02-19', '2024-02-19', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `accounts_type`
--

CREATE TABLE `accounts_type` (
  `id` int(11) NOT NULL,
  `account_name` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `related_internal_account` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='أنواع الحسابات المالية';

--
-- Dumping data for table `accounts_type`
--

INSERT INTO `accounts_type` (`id`, `account_name`, `status`, `related_internal_account`) VALUES
(1, 'رأس المال', 1, 0),
(2, 'مورد', 1, 0),
(3, 'عميل', 1, 0),
(4, 'مندوب', 1, NULL),
(5, 'موظف', 1, NULL),
(6, 'بنكي', 1, 0),
(7, 'مصروفات', 1, 0),
(8, 'قسم داخلي', 0, NULL),
(9, 'عام', 1, 0),
(10, 'الإيرادات', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `account tree`
--

CREATE TABLE `account tree` (
  `id` int(11) NOT NULL,
  `acc_serial` bigint(255) NOT NULL COMMENT 'رقم الحساب \r\nالأصول الثابته تبدا من الرقم 11000\r\nالأصول المتداوله تبدأ من الرقم 12000\r\n',
  `acc_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account tree`
--

INSERT INTO `account tree` (`id`, `acc_serial`, `acc_name`, `created_at`, `updated_at`) VALUES
(1, 10000, 'الأصول', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(2, 20000, 'الخصوم', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(3, 30000, 'حقوق الملكية', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(4, 40000, 'الإيرادات', '2024-01-14 19:39:29', '2024-01-14 19:39:29'),
(5, 50000, 'المصروفات', '2024-01-14 19:39:29', '2024-01-14 19:39:29');

-- --------------------------------------------------------

--
-- Table structure for table `account_second`
--

CREATE TABLE `account_second` (
  `id` int(11) NOT NULL,
  `acc_one_id` int(11) NOT NULL,
  `acc_serial` bigint(255) NOT NULL COMMENT 'رقم الحساب \r\nالأصول الثابته تبدا من الرقم 11000\r\nالأصول المتداوله تبدأ من الرقم 12000\r\n',
  `acc_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_second`
--

INSERT INTO `account_second` (`id`, `acc_one_id`, `acc_serial`, `acc_name`, `created_at`, `updated_at`) VALUES
(1, 1, 11000, 'الأصول الثابتة', '2024-01-14 20:12:42', '2024-01-14 20:12:42'),
(2, 1, 12000, 'الأصول المتداولة', '2024-01-14 20:12:42', '2024-01-14 20:12:42'),
(3, 2, 21000, 'القروض والديون', '2024-01-14 20:21:03', '2024-01-14 20:21:03'),
(4, 2, 22000, 'الحسابات المدفوعه مقدما', '2024-01-14 20:21:03', '2024-01-14 20:21:03'),
(9, 3, 31000, 'رأس المال', '2024-01-14 20:22:26', '2024-01-14 20:22:26'),
(10, 4, 41000, 'المبيعات', '2024-01-14 20:22:26', '2024-01-14 20:22:26'),
(11, 4, 42000, 'الإيرادات الخرى', '2024-01-14 20:23:14', '2024-01-14 20:23:14'),
(12, 5, 51000, 'المصروفات العامة', '2024-01-14 20:23:14', '2024-01-14 20:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(191) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `full_name`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', 'admin@admin', NULL, 'admin', NULL, NULL, NULL),
(2, '1', '1', '1', NULL, '1', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins_shifts`
--

CREATE TABLE `admins_shifts` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `treasures_id` int(11) DEFAULT NULL,
  `money_started_balanced` int(11) DEFAULT 0 COMMENT 'المبلغ الموجود في الخزينة حالة بدأ الشفت',
  `started_date` date DEFAULT NULL COMMENT 'وقت بدأ الشفت',
  `end_date` date DEFAULT NULL COMMENT 'وقت انتهاء الشفت',
  `is_finished` tinyint(4) DEFAULT 0 COMMENT 'هل انتهى الشفت',
  `total_of_shift` decimal(10,0) DEFAULT 0 COMMENT 'إجمالي الوردية',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins_treasures`
--

CREATE TABLE `admins_treasures` (
  `id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `treasures_id` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='صلاحيات خزن المستخدمين الخاصة\r\nاضافة خزن للمستخدمين';

-- --------------------------------------------------------

--
-- Table structure for table `bill_type`
--

CREATE TABLE `bill_type` (
  `id` int(11) NOT NULL,
  `bill_type_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill_type`
--

INSERT INTO `bill_type` (`id`, `bill_type_name`) VALUES
(1, 'فاتورة مبيعات مبدئية\r\n'),
(2, 'فاتورة مشتريات مبدئية\r\n'),
(3, 'فاتورة مبيعات'),
(4, 'فاتورة  مشتريات'),
(5, 'فاتورة  مردود مبيعات'),
(6, 'فاتورة  مردود فاتورة  مردود مشتريات'),
(7, 'بضاعه أول مدة');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_name` varchar(191) NOT NULL,
  `cat_description` varchar(191) DEFAULT NULL,
  `status` tinyint(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cat_name`, `cat_description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'قسم الأواني المنزلية', 'احتياجات المنزل عام', 1, '2024-01-12 11:08:59', '2024-01-31 04:28:35'),
(2, 'قسم الرجال', 'القسم خاص بمستلزمات الرجال', 1, '2024-01-12 11:10:48', '2024-01-31 04:29:13'),
(3, 'قسم النساء', 'يختص بمستلزمات النساء', 1, '2024-01-12 11:14:01', '2024-01-31 04:29:34'),
(4, 'قسم الملابس الأطفالي', NULL, 1, '2024-01-12 11:14:58', '2024-01-12 11:14:58'),
(5, 'قسم الإكسسوارات', 'يهتم بالإكسسوارات فقط', 1, '2024-01-31 04:30:05', '2024-01-31 04:30:05'),
(6, 'أجهزة الكمبيوتر', 'شاشاات - كمبيوترات - اجهزة لاب توب', 1, '2024-01-31 04:30:35', '2024-01-31 04:30:35'),
(7, 'قسم البلاي ستيشن', '1 - 2 - 3 - 4 - 5', 1, '2024-01-31 04:31:02', '2024-01-31 04:31:02'),
(8, 'قسم الثلاجات', 'ثلاجات كل المقاسات', 1, '2024-02-25 17:16:01', '2024-03-08 19:08:36');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `account_number` int(11) DEFAULT NULL,
  `customer_name` varchar(191) NOT NULL,
  `start_balance` decimal(10,2) DEFAULT 0.00,
  `current_balance` decimal(10,2) DEFAULT 0.00,
  `customer_address` varchar(191) DEFAULT NULL,
  `customer_phone` varchar(191) DEFAULT NULL,
  `customer_email` varchar(191) DEFAULT NULL,
  `customer_imge` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `account_number`, `customer_name`, `start_balance`, `current_balance`, `customer_address`, `customer_phone`, `customer_email`, `customer_imge`, `created_at`, `updated_at`) VALUES
(1, 1211001, 'محمد عثمان', '0.00', '0.00', 'امبدة', NULL, 'test@test.com', '5075990760be43a69c2408c5e793d981.jpg', '2024-02-19 06:59:21', '2024-02-19 06:59:21');

-- --------------------------------------------------------

--
-- Table structure for table `inv_itemcart_movments`
--

CREATE TABLE `inv_itemcart_movments` (
  `id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `item_code` bigint(20) NOT NULL,
  `items_movments_types` int(11) NOT NULL,
  `FK_table` bigint(20) NOT NULL,
  `FK_table_detailse` bigint(20) NOT NULL,
  `byan` varchar(255) NOT NULL,
  `qty_before_movement` varchar(255) NOT NULL,
  `qty_after_movement` varchar(255) NOT NULL,
  `added_by` int(11) NOT NULL,
  `date` date NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inv_itemcart_movment_types`
--

CREATE TABLE `inv_itemcart_movment_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='أنواع الحركات إما أن تكون مشتريات او مبيعات او مخازن';

--
-- Dumping data for table `inv_itemcart_movment_types`
--

INSERT INTO `inv_itemcart_movment_types` (`id`, `name`) VALUES
(1, 'مشتريات'),
(2, 'مرتجع مشتريات'),
(3, 'مبيعات'),
(4, 'مرتجع مبيعات'),
(5, 'تحويل بين المخازن');

-- --------------------------------------------------------

--
-- Table structure for table `inv_item_cart`
--

CREATE TABLE `inv_item_cart` (
  `id` int(11) NOT NULL,
  `name` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inv_item_movment_category`
--

CREATE TABLE `inv_item_movment_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='فئات الحركات تندرج تحتها انواع الحركات ';

--
-- Dumping data for table `inv_item_movment_category`
--

INSERT INTO `inv_item_movment_category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'حركه على المشتريات', NULL, NULL),
(2, 'حركه على المبيعات', NULL, NULL),
(3, 'حركه على المخازن', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mony_move_type`
--

CREATE TABLE `mony_move_type` (
  `id` int(11) NOT NULL,
  `mony_move_type` varchar(50) DEFAULT NULL,
  `screen_show` varchar(50) DEFAULT NULL,
  `move_type` int(11) DEFAULT NULL COMMENT 'نوع الحركة هل هي صرف ام تحصيل\r\n-صرف = 1\r\nنحصيل = 2',
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='انواع الحركات المالية';

--
-- Dumping data for table `mony_move_type`
--

INSERT INTO `mony_move_type` (`id`, `mony_move_type`, `screen_show`, `move_type`, `status`) VALUES
(1, ' مراجعة واستلام نقدية شفت على نفس الخزينة', 'بشاشة التحصيل', 2, 0),
(2, 'مراجعة واستلام نقدية شفت خزنة اخرى', 'بشاشة التحصيل', 2, 0),
(3, 'صرف مبلغ لحساب مالي', 'بشاشة الصرف', 1, 0),
(4, 'تحصيل مبلغ من حساب مالي', 'بشاشة التحصيل', 2, 0),
(5, 'تحصيل ايراد مبيعات', 'بشاشة التحصيل', 2, 0),
(6, 'صرف نظير مرتجع مبيعات', 'بشاشة الصرف', 1, 0),
(7, 'صرف نظير مشتريات من مورد', 'بشاشة الصرف', 1, 0),
(8, 'تحصيل نظير مرتجع مشتريات الى مورد', 'بشاشة التحصيل', 2, 0),
(9, 'ايراد زيادة رأس المال', 'بشاشة التحصيل', 2, 0),
(10, 'مصاريف عامة', 'بشاشة الصرف', 1, 1),
(11, 'صرف للإيداع البنكي', 'بشاشة الصرف', 1, 0),
(12, 'سحب من البنك', 'بشاشة التحصيل', 2, 0),
(13, 'صرف لرد رأس المال', 'بشاشة الصرف', 1, 0),
(23, 'بضاعة أول المدة', 'بشاشه الصرف', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(191) NOT NULL,
  `customer_email` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pay_type`
--

CREATE TABLE `pay_type` (
  `id` int(11) NOT NULL,
  `pay_type_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pay_type`
--

INSERT INTO `pay_type` (`id`, `pay_type_name`) VALUES
(1, 'كاش'),
(2, 'أجل'),
(3, 'جزء أجل و جزء كاش');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `product_serial` varchar(255) DEFAULT NULL,
  `product_name` varchar(191) NOT NULL,
  `product_description` varchar(191) DEFAULT NULL,
  `purshace_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL COMMENT 'رقم المخزن المراد الإضافة فيه',
  `qty` int(11) DEFAULT NULL,
  `does_has_unit` tinyint(4) DEFAULT 0 COMMENT 'هل للصنف وحدة تجزئة',
  `unit_id` int(11) DEFAULT 0 COMMENT 'كود وحدة قياس الأب',
  `retail_uom_qty_to_parent` int(11) DEFAULT 0 COMMENT 'كم حبة في الوحدة',
  `risk` int(11) DEFAULT 10,
  `photo` varchar(255) DEFAULT NULL,
  `move_type` int(11) DEFAULT NULL,
  `bill_type` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `creation_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `product_serial`, `product_name`, `product_description`, `purshace_price`, `price`, `stock`, `qty`, `does_has_unit`, `unit_id`, `retail_uom_qty_to_parent`, `risk`, `photo`, `move_type`, `bill_type`, `note`, `creation_date`, `expiration_date`, `created_at`, `updated_at`) VALUES
(3, 8, '80003', 'LG-1', 'LG-1', 5000, 7000, 1, NULL, 0, NULL, 0, 10, '17099337765732.png', 23, 7, 'إضافة صنف', NULL, NULL, '2024-03-08 19:36:16', '2024-03-08 19:36:16'),
(4, 8, '80004', 'LG-2', 'LG-2', 6500, 7500, 1, NULL, 0, NULL, 0, 6, '17099338058841.png', 23, 7, 'إضافة صنف', NULL, NULL, '2024-03-08 19:36:45', '2024-03-08 19:36:45'),
(5, 6, '60005', 'hp', 'hp', 15000, 20000, 1, NULL, 0, NULL, 0, 30, '1709933839403.png', 23, 7, 'إضافة صنف', NULL, NULL, '2024-03-08 19:37:19', '2024-03-08 19:37:19');

-- --------------------------------------------------------

--
-- Table structure for table `salse`
--

CREATE TABLE `salse` (
  `id` int(11) NOT NULL,
  `account_number` int(11) DEFAULT 0,
  `serial` varchar(191) DEFAULT NULL,
  `is_approved` tinyint(4) DEFAULT 0,
  `approved_by` int(11) DEFAULT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT 0 COMMENT 'العميل 0 يعني انه ليس لديه حساب في النظام',
  `bill_type` int(11) DEFAULT NULL,
  `pay_type` int(11) DEFAULT NULL,
  `what_paid` int(11) DEFAULT NULL,
  `what_not_yet_paid` int(11) DEFAULT NULL,
  `discount_amount` decimal(10,0) DEFAULT 0,
  `total` decimal(10,2) DEFAULT 0.00,
  `note` varchar(50) DEFAULT NULL,
  `treasures_id` int(11) DEFAULT NULL,
  `total_item_count` int(11) DEFAULT NULL COMMENT 'العدد الكلي للأصناف في الفاتورة',
  `date` date DEFAULT curdate(),
  `created_at` timestamp NULL DEFAULT curdate(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `salse_detailse`
--

CREATE TABLE `salse_detailse` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `salse_id` int(20) NOT NULL,
  `auto_serial` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `qty` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `store_id` int(11) DEFAULT 1,
  `created_at` date DEFAULT curdate(),
  `updated_at` date DEFAULT NULL,
  `move_type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_company`
--

CREATE TABLE `settings_company` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(191) NOT NULL,
  `company_logo` varchar(191) NOT NULL,
  `company_address` varchar(191) NOT NULL,
  `company_phone` varchar(191) NOT NULL,
  `company_description` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stock_name` varchar(50) NOT NULL DEFAULT '',
  `stock_qty` int(11) DEFAULT NULL,
  `stock_location` varchar(50) DEFAULT NULL,
  `created_at` date DEFAULT current_timestamp(),
  `updated_at` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `stock_name`, `stock_qty`, `stock_location`, `created_at`, `updated_at`) VALUES
(1, 'المعرض', NULL, NULL, NULL, '2023-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `stock_data`
--

CREATE TABLE `stock_data` (
  `id` int(11) NOT NULL,
  `auto_serial` varchar(255) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `cat_id` int(10) UNSIGNED DEFAULT NULL,
  `pro_id` int(10) UNSIGNED DEFAULT NULL,
  `unit_id` int(10) UNSIGNED DEFAULT NULL,
  `unit_cost_price` decimal(10,2) UNSIGNED DEFAULT NULL,
  `qty` decimal(10,2) UNSIGNED DEFAULT NULL,
  `total_cost_unit` decimal(10,2) UNSIGNED DEFAULT NULL,
  `risk` int(11) DEFAULT 10,
  `bill_type` bigint(20) UNSIGNED DEFAULT NULL,
  `move_type` bigint(20) UNSIGNED DEFAULT NULL,
  `production_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_data`
--

INSERT INTO `stock_data` (`id`, `auto_serial`, `batch_id`, `store_id`, `cat_id`, `pro_id`, `unit_id`, `unit_cost_price`, `qty`, `total_cost_unit`, `risk`, `bill_type`, `move_type`, `production_date`, `expiration_date`, `created_at`, `updated_at`) VALUES
(3, NULL, 1, 1, 8, 3, NULL, '7000.00', '150.00', '1050000.00', 10, 7, 23, NULL, NULL, '2024-03-08 19:36:16', '2024-03-08 19:36:16'),
(4, NULL, 2, 1, 8, 4, NULL, '7500.00', '36.00', '270000.00', 6, 7, 23, NULL, NULL, '2024-03-08 19:36:46', '2024-03-08 19:36:46'),
(5, NULL, 3, 1, 6, 5, NULL, '20000.00', '100.00', '2000000.00', 30, 7, 23, NULL, NULL, '2024-03-08 19:37:20', '2024-03-08 19:37:20');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `sup_name` varchar(155) NOT NULL,
  `start_balance` decimal(10,2) DEFAULT NULL,
  `current_balance` decimal(10,2) DEFAULT NULL,
  `sup_address` varchar(155) DEFAULT NULL,
  `sup_phone` varchar(155) DEFAULT NULL,
  `sup_email` varchar(150) DEFAULT NULL,
  `sup_image` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `account_number`, `sup_name`, `start_balance`, `current_balance`, `sup_address`, `sup_phone`, `sup_email`, `sup_image`, `created_at`, `updated_at`) VALUES
(1, '1212001', 'نصرالدين عثمان', '0.00', '0.00', 'امبدة', NULL, 'test@test.com', NULL, '2024-02-19', '2024-02-19');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_with_order`
--

CREATE TABLE `supplier_with_order` (
  `id` int(11) NOT NULL,
  `auto_serial` int(11) DEFAULT NULL,
  `is_approved` tinyint(4) DEFAULT 0 COMMENT 'هل تم اعتماد الفاتورة\r\n',
  `approved_by` int(11) DEFAULT NULL,
  `bill_type` tinyint(4) DEFAULT NULL COMMENT 'نوع الفاتورة هل هي\r\n1- فاتورة مشتريات\r\n2- فاتورة مرتجع مشتريات على نفس الفاتورة\r\n3- هل هي مرتجع عام بترجع بدون تقيد بأصل الفاتورة',
  `order_pay_type` int(11) DEFAULT NULL,
  `order_date` date DEFAULT curdate(),
  `supplier_id` int(11) DEFAULT 0 COMMENT 'العميل 0 يعني انه ليس لديه حساب في النظام',
  `account_number` int(11) DEFAULT NULL,
  `total_cost` decimal(10,0) DEFAULT 0,
  `money_for_account` decimal(10,0) DEFAULT 0,
  `what_paid` decimal(10,0) DEFAULT 0,
  `what_remain` decimal(10,0) DEFAULT 0,
  `treasures_transaction_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL COMMENT 'كود المخزن',
  `treasures_id` int(11) DEFAULT NULL,
  `supplier_balance_before` decimal(10,0) DEFAULT 0 COMMENT 'حاله رصيد المورد قبل الفاتورة',
  `supplier_balance_fater` decimal(10,0) DEFAULT NULL COMMENT 'حاله رصيد المورد بعد الفاتورة',
  `note` varchar(50) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='جدول مشتريات ومرتجعات الموردين';

-- --------------------------------------------------------

--
-- Table structure for table `supplier_with_order_detailse`
--

CREATE TABLE `supplier_with_order_detailse` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `item_qty` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` int(11) DEFAULT NULL COMMENT 'سعر الوحدة',
  `total_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الوحدة ضرب الكمية',
  `creation_product` date DEFAULT NULL,
  `expiration_product` date DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL COMMENT 'رقم الباتش في المخزن الذي تم التخزين الصنف بها',
  `created_at` date DEFAULT current_timestamp(),
  `updated_at` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='تفاصيل أصناف فاتورة المشتريات والمرتجعات';

-- --------------------------------------------------------

--
-- Table structure for table `treasures`
--

CREATE TABLE `treasures` (
  `id` int(11) NOT NULL,
  `treasures_serial` varchar(255) DEFAULT NULL,
  `treasures_name` varchar(155) NOT NULL,
  `is_master` tinyint(4) DEFAULT 0,
  `last_isal_exchange` bigint(20) DEFAULT NULL,
  `last_isal_collect` bigint(20) DEFAULT NULL,
  `isal_for_first_insert` int(11) DEFAULT NULL COMMENT 'ايصال لتحديد الأصناف التي تمت إضافتها',
  `money` decimal(10,2) NOT NULL DEFAULT 0.00,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `treasures`
--

INSERT INTO `treasures` (`id`, `treasures_serial`, `treasures_name`, `is_master`, `last_isal_exchange`, `last_isal_collect`, `isal_for_first_insert`, `money`, `active`, `created_at`, `updated_at`) VALUES
(1, '10-T', 'الخزنة الرئيسية', 1, 0, 0, NULL, '3320000.00', 1, '2024-01-11 04:25:36', '2024-03-08 21:37:20');

-- --------------------------------------------------------

--
-- Table structure for table `treasures_delevry`
--

CREATE TABLE `treasures_delevry` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `treasures_transactions`
--

CREATE TABLE `treasures_transactions` (
  `id` int(11) NOT NULL,
  `isal_number` int(11) DEFAULT NULL COMMENT 'كود العملية',
  `shift_code` int(11) DEFAULT NULL COMMENT 'كود الشفت للمستخدم',
  `treasures_id` int(11) DEFAULT NULL,
  `is_account` int(11) DEFAULT NULL COMMENT 'هل هو حساب مالي',
  `account_type` int(11) DEFAULT NULL COMMENT 'نوع الحساب هل هو رأس مال ام عميل ام مورد او غيرة',
  `account_number` bigint(20) DEFAULT NULL COMMENT 'رقم الحساب المالي',
  `money` decimal(10,0) DEFAULT 0 COMMENT 'قيمة المبلغ المتحصل او المصروف بالخزنة',
  `money_for_account` decimal(10,0) DEFAULT 0 COMMENT 'قيمة المبلغ المستحق او المخصوم من الحساب المالي',
  `foreign_key` bigint(20) DEFAULT NULL COMMENT 'كود الجدول الأخر المرتبط بالحركة',
  `move_type_id` int(11) DEFAULT NULL COMMENT 'نوع الحركة النقدية',
  `note` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='جدول حركة النقدية\r\nبالشفتات\r\nكل العمليات المالية بتصب فيه \r\nلازم كل العمليات تسمع عليه';

--
-- Dumping data for table `treasures_transactions`
--

INSERT INTO `treasures_transactions` (`id`, `isal_number`, `shift_code`, `treasures_id`, `is_account`, `account_type`, `account_number`, `money`, `money_for_account`, `foreign_key`, `move_type_id`, `note`, `date`, `added_by`, `created_at`, `updated_at`) VALUES
(5, 1000, 1, 1, 0, NULL, NULL, '1050000', '0', NULL, 23, NULL, '2024-03-08', 1, '2024-03-08 21:36:16', '2024-03-08 21:36:16'),
(6, 1000, 1, 1, 0, NULL, NULL, '270000', '0', NULL, 23, NULL, '2024-03-08', 1, '2024-03-08 21:36:46', '2024-03-08 21:36:46'),
(7, 1000, 1, 1, 0, NULL, NULL, '2000000', '0', NULL, 23, NULL, '2024-03-08', 1, '2024-03-08 21:37:20', '2024-03-08 21:37:20');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unit_name` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `unit_name`, `created_at`, `updated_at`) VALUES
(1, 'كيلو', '2024-01-12 20:59:54', '2024-01-12 20:59:54'),
(2, 'دسته', '2024-02-19 06:35:43', '2024-02-19 06:35:43'),
(3, 'حبة', '2024-02-19 06:35:53', '2024-02-19 06:35:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(150) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`) VALUES
(1, 'admin', 'admin@admin', 'admin', '123'),
(2, '1', '1', '1', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_type` (`account_type`);

--
-- Indexes for table `accounts_type`
--
ALTER TABLE `accounts_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account tree`
--
ALTER TABLE `account tree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_second`
--
ALTER TABLE `account_second`
  ADD PRIMARY KEY (`id`),
  ADD KEY `acc_one` (`acc_one_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins_shifts`
--
ALTER TABLE `admins_shifts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill_type`
--
ALTER TABLE `bill_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_itemcart_movments`
--
ALTER TABLE `inv_itemcart_movments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_itemcart_movment_types`
--
ALTER TABLE `inv_itemcart_movment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_item_cart`
--
ALTER TABLE `inv_item_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_item_movment_category`
--
ALTER TABLE `inv_item_movment_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mony_move_type`
--
ALTER TABLE `mony_move_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_type`
--
ALTER TABLE `pay_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `salse`
--
ALTER TABLE `salse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salse_detailse`
--
ALTER TABLE `salse_detailse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salse_id` (`salse_id`);

--
-- Indexes for table `settings_company`
--
ALTER TABLE `settings_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_data`
--
ALTER TABLE `stock_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_with_order`
--
ALTER TABLE `supplier_with_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_with_order_detailse`
--
ALTER TABLE `supplier_with_order_detailse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_order` (`order_id`);

--
-- Indexes for table `treasures`
--
ALTER TABLE `treasures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treasures_transactions`
--
ALTER TABLE `treasures_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `move_id` (`move_type_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `account tree`
--
ALTER TABLE `account tree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `account_second`
--
ALTER TABLE `account_second`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admins_shifts`
--
ALTER TABLE `admins_shifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bill_type`
--
ALTER TABLE `bill_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inv_itemcart_movments`
--
ALTER TABLE `inv_itemcart_movments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inv_itemcart_movment_types`
--
ALTER TABLE `inv_itemcart_movment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `inv_item_cart`
--
ALTER TABLE `inv_item_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inv_item_movment_category`
--
ALTER TABLE `inv_item_movment_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mony_move_type`
--
ALTER TABLE `mony_move_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_type`
--
ALTER TABLE `pay_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `salse`
--
ALTER TABLE `salse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `salse_detailse`
--
ALTER TABLE `salse_detailse`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `settings_company`
--
ALTER TABLE `settings_company`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stock_data`
--
ALTER TABLE `stock_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `supplier_with_order`
--
ALTER TABLE `supplier_with_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supplier_with_order_detailse`
--
ALTER TABLE `supplier_with_order_detailse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `treasures`
--
ALTER TABLE `treasures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `treasures_transactions`
--
ALTER TABLE `treasures_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `account_type` FOREIGN KEY (`account_type`) REFERENCES `accounts_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `account_second`
--
ALTER TABLE `account_second`
  ADD CONSTRAINT `acc_one` FOREIGN KEY (`acc_one_id`) REFERENCES `account tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `salse_detailse`
--
ALTER TABLE `salse_detailse`
  ADD CONSTRAINT `salse_id` FOREIGN KEY (`salse_id`) REFERENCES `salse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `supplier_with_order_detailse`
--
ALTER TABLE `supplier_with_order_detailse`
  ADD CONSTRAINT `supplier_order` FOREIGN KEY (`order_id`) REFERENCES `supplier_with_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `treasures_transactions`
--
ALTER TABLE `treasures_transactions`
  ADD CONSTRAINT `move_id` FOREIGN KEY (`move_type_id`) REFERENCES `mony_move_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
