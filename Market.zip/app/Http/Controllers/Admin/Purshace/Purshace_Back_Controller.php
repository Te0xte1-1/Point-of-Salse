<?php

namespace App\Http\Controllers\Admin\Purshace;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Purshace_Back_Controller extends Controller
{
 
    public function create()
    {
        abort(404);
    }

 
    public function store(Request $request)
    {
        abort(404);
    }

  
    public function show()
    {
        //
    }


    public function edit()
    {
        //
    }

 
    public function update(Request $request)
    {
        //
    }


    public function destroy()
    {
        abort(404);
    }
}
