<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class accounts extends Model
{
    use HasFactory;
    protected $table = 'accounts';
    protected $guarded = [];
    // protected $hidden = ['created_at', 'updated_at'];
}
