<div class="table-responsive">
    <table id="dataTable" class="table table-bordered table-stripped table-hover">
        <thead class="table table-primary">
            <th width="2%">#</th>
            <th width="10%">نوع الفاتورة</th>
            <th width="10%">رقم الفاتورة</th>
            <th width="10%">تاريخ الفاتورة</th>
            <th width="8%">نوع السداد</th>
            <th width="13%">اسم العميل</th>
            <th>المدفوع</th>
            <th>المتبقي</th>
            <th>قيمة الفاتورة</th>
            <th width="20%">اكشن</th>
        </thead>
        <tbody>
            <?php if(!empty($Salse)): ?>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $Salse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($item->bill_type); ?></td>
                        <td><?php echo e($item->serial); ?></td>
                        <td><?php echo e($item->date); ?></td>
                        <td><?php echo e($item->pay_type); ?></td>
                        <td>
                            <?php if($item->acc_name == ""): ?>
                                عميل 
                            <?php else: ?>
                            <?php echo e($item->acc_name); ?>

                            <?php endif; ?>
                            </td>
                        <td><?php echo e($item->what_paid); ?></td>
                        <td><?php echo e($item->what_not_yet_paid); ?></td>
                        <td><strong>
                                <?php echo e($item->total); ?>

                            </strong>
                        </td>
                        <td>
                            <?php if($item->is_approved == 0): ?>
                                <a href="#" class="btn btn-warning btn-sm" id="edit_bill"
                                    data-bill-id=" <?php echo e($item->id); ?>" title="تعديل في الفاتورة"> تعديل
                                </a>
                                <a href="#"class="btn btn-success btn-sm" data-toggle="modal"
                                    data-target="#modal-lg-showd" title="تفاصيل الفاتورة">A4 <i class="fa fa-print"></i>
                                </a>
                                <a href="#"class="btn btn-info btn-sm" data-toggle="modal"
                                    data-target="#modal-lg-showd" title="تفاصيل الفاتورة">A6 <i class="fa fa-print"></i>
                                </a>

                                <button class="btn btn-danger btn-sm" data-id="<?php echo e($item->id); ?>"
                                    id="remove_salse_invoice">
                                    <i class="fa fa-trash"></i>
                                </button>
                            <?php else: ?>
                                <button class=" btn btn-primary btn-sm" data-id="<?php echo e($item->id); ?>"
                                    id="print_salse_invoice">
                                    فاتورة تمت
                                    <i class="fa fa-check"></i>
                                </button>
                                <a href="<?php echo e(route('Salse.done_print.a6', $item->id, 'A6')); ?>"class="btn btn-success btn-sm"
                                    title="طباعة الفاتورة">A6 <i class="fa fa-print"></i>
                                </a>
                                <a href="<?php echo e(route('Salse.done_print.a4', $item->id, 'A4')); ?>"class="btn btn-info btn-sm"
                                    title="طباعة الفاتورة">A4 <i class="fa fa-print"></i>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="10" class="alert alert-danger">لا توجد فاتورة بعد</td>
                </tr>
            <?php endif; ?>

        </tbody>
        <tfoot>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>إجمالي الفواتير <strong>(<?php echo e($total_salse); ?>)</strong></td>
            <td></td>
        </tfoot>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\Market\resources\views/Salse/load_salse/load_salse_table.blade.php ENDPATH**/ ?>