

<?php $__env->startSection('title'); ?>
    Stock
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .show_products {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        }

        .info-box {
            box-shadow: 0 0 1px rgba(0, 0, 0, .125), 0 1px 3px rgba(0, 0, 0, .2);
            border-radius: 1px !important;
            background-color: #fff;
            display: -ms-flexbox;
            display: flex;
            border: 1px solid #ddd;
            margin-bottom: 1rem;
            min-height: 80px;
            padding: 0.5rem;
            position: relative;
            width: 100%;
        }
    </style>
    <div class="container-fluid">

        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header text-right">
                        <h6 class="text-center">
                            عرض الأصناف في المخزن رقم
                            (المعرض)
                            <a class="text-left" title="رجوع لصفحة المخازن" href="<?php echo e(route('Stock')); ?>" class="text-left">
                                رجوع للمخازن
                                <i class="fa fa-arrow-left"></i>
                            </a>
                        </h6>
                        <br>
                        <select name="cat_id" class="form-control form-control-sm" id="cat_id">
                            <option value="">اختر القسم</option>
                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->cat_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        
                        

                        <div class="show_products">

                            <table class="table table-hover stripped bordered" id="dataTable">
                                <thead>
                                    <th>اسم القسم</th>
                                    <th>اسم الصنف</th>
                                    <th>رقم الباتش</th>
                                    <th>كمية الصنف في المخزن</th>
                                    <th>سعر الصنف</th>
                                    <th> إجمالي السعر</th>
                                    <th>حد الطلب </th>
                                    <th>تاريخ الإنتهاء </th>
                                </thead>
                                <tbody id="show_data_by_cat">
                                    <?php if(!empty($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->category_name); ?></td>
                                                <td><?php echo e($item->product_name); ?></td>
                                                <td><?php echo e($item->batch_id); ?></td>
                                                <td><?php echo e($item->qty); ?></td>
                                                <td><?php echo e($item->unit_cost_price); ?></td>
                                                <td><?php echo e($item->total_cost_unit); ?></td>
                                                <td><?php echo e($item->risk); ?></td>
                                                <td>
                                                    <?php if($item->expiration_date == ''): ?>
                                                        بدون تاريخ إنتهاء
                                                    <?php else: ?>
                                                        <?php echo e($item->expiration_date); ?>

                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        نأسف لا توجد أصناف في هذا المخزن
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card-body -->


                    
                    <div class="modal fade" id="modal-cat_edit">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">تعديل البيانات</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="اغلاق">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('Stock.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="card-body">

                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <button type="button" class="btn btn-default btn-sm"
                                                    data-dismiss="modal">إغلاق</button>
                                                <button type="submit" class="btn btn-primary btn-sm">تأكيد</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        
        $(document).on('change', '#cat_id', (function() {
            var cat_id = $(this).val();
            $.ajax({
                method: 'POST',
                url: "<?php echo e(route('Stock.get_product_by_cat')); ?>",
                dataType:'html',
                data: {
                    cat_id: cat_id
                },
                success: function(data) {
                    $("#show_data_by_cat").html(data);
                }
            });

        }));

    });
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/stock/show_products.blade.php ENDPATH**/ ?>