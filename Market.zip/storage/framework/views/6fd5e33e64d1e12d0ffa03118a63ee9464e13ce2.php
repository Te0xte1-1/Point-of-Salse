<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Dashboard</title>

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/select2-bootstrap4.min.css')); ?>">
</head>
<style>
    body {
        direction: rtl;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
        background: #0f2e55;

    }

    .navbar-dark {
        position: fixed;
        left: 0;
        width: 1287px;
        height: 45px;
        z-index: 100;
        top: 0;
        background-color: #343a40;
        border-color: #4b545c;
    }

    [class*=sidebar-light-] .sidebar a {
        color: #fbfdff;
    }

    .layout-fixed .main-sidebar {
        bottom: 0;
        float: none;
        right: 0 !important;
        position: fixed;
        top: 0;
        background: #0f2e55;
        color: #f4f6f9;
        box-shadow: none !important;
    }

    [class*=sidebar-light-] .nav-treeview>.nav-item>.nav-link {
        color: #fff !important;
        border-top: 1px solid #ded3d3;

    }

    [class*=sidebar-light-] .nav-sidebar>.nav-item.menu-open>.nav-link,
    [class*=sidebar-light-] .nav-sidebar>.nav-item:hover>.nav-link {
        background-color: rgba(233, 228, 228, 0.1);
        color: #fff;
    }

    .sidebar-dark-primary .nav-sidebar>.nav-item>.nav-link.active,
    .sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active {
        /* background-color: rgba(0, 0, 255, 0.805); */
        color: #fff !important;
        border: none !important;
    }

    [class*=sidebar-light-] .nav-sidebar>.nav-item>.nav-link:active,
    [class*=sidebar-light-] .nav-sidebar>.nav-item>.nav-link:focus {
        color: #fdfeff;
        background: #007bff;
    }

    [class*=sidebar-light-] .nav-sidebar>.nav-item>.nav-link.active {
        color: #000;
        box-shadow: none;
    }

    [class*=sidebar-light-] .nav-sidebar>.nav-item>.nav-link.active {
        color: #000000a1;
        background: #343a40;
        /* font-size: 14px; */
        font-weight: 500;
        box-shadow: none;

    }

    .nav-sidebar .nav-item>.nav-link {
        position: relative;
        margin-right: -24px;
        text-align: right;
    }

    .nav-sidebar>.nav-item {
        margin-bottom: 0;
        margin-right: -20px;
    }



    [class*=sidebar-light-] .nav-treeview>.nav-item>.nav-link {
        color: #777;
        border-top: 1px solid #ded3d3;
        font-size: 14px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        /* width: fit-content; */
        /* margin-left: 17px; */
        /* text-align: center; */
    }

    main {
        margin-right: 250px !important;
        /* border: 1px solid !important; */
        /* width: 1257px !important; */
    }

    .pt-4,
    .py-4 {
        background: #f4f6f9;
        min-height: 700px;
        /* padding-top: 3.5rem !important; */
        padding-right: 15px !important;
        padding-left: 15px !important;
    }

    .navbar-light .navbar-nav .nav-link {
        color: white;
    }

    [class*=sidebar-light] .brand-link,
    [class*=sidebar-light] .brand-link .pushmenu {
        color: rgb(255 255 255 / 80%);
    }

    th {
        font-size: 15px;
        /* font-weight: bold; */
        text-align: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    td {

        font-size: 14px;
        text-align: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .main-footer {

        background-color: #20407d;
        border-top: 1px solid #35699d;
        color: #869099;
        position: fixed;
        /* left: 0; */
        bottom: 0;
        z-index: 1;
        width: 100%;
        padding: 1px;
    }

    label {
        float: right !important;
        margin-right: 14px;
    }
</style>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-light-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?php echo e(route('Dashboard')); ?>" class="brand-link">
                <img src="<?php echo e(asset('img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo"
                    class="brand-image img-circle elevation-3" style="opacity: .8">
                <span class="brand-text font-weight-light">Dashboard</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel (optional) -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image">
                        <img src="<?php echo e(asset('img/photo4.jpg')); ?>" class="img-square " alt="User Image">
                    </div>
                    <div class="info">
                        <a href="#" class="">Admin</a>
                    </div>
                </div>


                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        
                        
                        

                        
                        <li class="nav-item has-treeview <?php echo e(request()->is('Settings') ? 'menu-open' : ''); ?>">
                            <a href="#" class="nav-link active" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-cog"></i>

                                <b>
                                    <p>
                                        الضبط العام
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Treasures')); ?>" class="nav-link">
                                        <i class="fas fa-cog nav-icon"></i>
                                        <p>بيانات الخزن</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Quick_access')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>الوصول السريع</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Users')); ?>" class="nav-link">
                                        <i class="fa fa-users nav-icon"></i>
                                        <p>المستخدمين</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Settings')); ?>" class="nav-link">
                                        <i class="fas fa-cog nav-icon"></i>
                                        <p>بيانات الشركة</p>
                                    </a>
                                </li>

                            </ul>
                        </li>
                        





                        
                        <li class="nav-item  <?php echo e(request()->is('Mony_Type_Move') ? 'menu-open' : ''); ?>">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-dollar-sign"></i>
                                <b>
                                    <p>
                                        الحسابات والنقدية
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Mony_Type_Move')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>أنواع الحركات النقدية</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('accounts_type')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>أنواع الحسابات المالية</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Account_Tree')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>جميع الحسابات المالية</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Esal_Srf_Mony')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>إيصال صرف نقدية</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Esal_Recive_Mony')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>إيصال تحصيل نقدية</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Status_Account_Mony')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>حالة حساب مالي</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Treasures_Balance')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>رصيد الخزن</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        



                        
                        <li class="nav-item">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <b>
                                    <p>
                                        ضبط المخازن
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Cat')); ?>" class="nav-link">
                                        <i class="fa fa-box nav-icon"></i>
                                        <p>أقسام الأصناف</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Pro')); ?>" class="nav-link">
                                        <i class="fa fa-flag nav-icon"></i>
                                        <p>الأصناف</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Units')); ?>" class="nav-link">
                                        <i class="fa fa-file nav-icon"></i>
                                        <p>الوحدات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Suppliers')); ?>" class="nav-link">
                                        <i class="fa fa-users nav-icon"></i>
                                        <p>الموردون</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Customers')); ?>" class="nav-link">
                                        <i class="fa fa-users nav-icon"></i>
                                        <p>العملاء</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Stock')); ?>" class="nav-link">
                                        
                                        <i class="fa fa-store nav-icon"></i>
                                        <p>المخازن</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Send_Between_Stocks')); ?>" class="nav-link">
                                        <i class="far fa-window-restore nav-icon"></i>
                                        <p>الترحيل بين المخازن</p>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        
                        <li class="nav-item">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <b>
                                    <p>
                                        حركات مخزنية
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Purshace')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>فواتير المشتريات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Purshace.preview')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>مراجعة فواتير المشتريات</p>
                                    </a>
                                </li>

                            </ul>
                        </li>


                        


                        
                        <li class="nav-item">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-shopping-cart"></i>
                                <b>
                                    <p>
                                        العمليات
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Salse')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>فواتير المبيعات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Purshace')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>الفواتيرالمبدئية</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Purshace')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>فواتير المشتريات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Purshace.preview')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>مراجعة فواتير المشتريات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Purshace_Back')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>مردود المشتريات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Salse_Back')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>مردود المبيعات</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        

                        
                        <li class="nav-item">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <b>
                                    <p>
                                        حركات شفت الخزينة
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Admin_Shifts')); ?>" class="nav-link">
                                        <i class="fa fa-key nav-icon"></i>
                                        <p>شفتات الخزينة</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Cat')); ?>" class="nav-link">
                                        <i class="fa fa nav-icon"></i>
                                        <p>تسليم وإنهاء الشفت الأن</p>
                                    </a>
                                </li>

                            </ul>
                        </li>

                        
                        <li class="nav-item">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <b>
                                    <p>
                                        الصلاحيات
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Admins')); ?>" class="nav-link">
                                        <i class="fa fa-pen nav-icon"></i>
                                        <p>صلاحيات المستخدمين</p>
                                    </a>
                                </li>

                            </ul>
                        </li>



                        
                        <li class="nav-item">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-edit"></i>
                                <b>
                                    <p>
                                        التقارير
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_All')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقرير مبيعات ومشتريات </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Check_Customer_Account')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>كشف حساب عميل</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Check_Supplier_Account')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>كشف حساب مورد</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Mony_Move_Of_Mony_Account')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>حركة النقدية على حساب مالي</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Salse_And_Alert_Ajl')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>المبيعات وتنبيهات البيع الأجل</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Win_Of_A_While')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقرير الربحية خلال فترة</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Win_Of_Pro_A_While')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقرير الربحية لصنف خلال فترة</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Purshace')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقارير المشتريات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Salse')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقارير المبيعات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Salse_Back')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقارير مردود المبيعات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Purshace_Back')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقارير مردود المشتريات</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Of_Stocks')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقارير المخازن</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Of_Treasures')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقارير الخزينة</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Report_Of_Pro_Risks')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>تقارير حد الأصناف </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        

                        
                        <li class="nav-item">
                            <a href="#" class="nav-link" style="border-top:1px solid#ddd">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <b>
                                    <p>
                                        المراقبة والدعم الفني
                                        <i style="float: left" class="fas fa-angle-left right"></i>
                                    </p>
                                </b>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('Cat')); ?>" class="nav-link">
                                        <i class="fa fa-box nav-icon"></i>
                                        <p>أقسام الأصناف</p>
                                    </a>
                                </li>

                            </ul>
                        </li>

                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

        <!-- main content -->
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>

        </main>
    </div>
    

    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>


    <!-- fontawesome -->
    <script src="<?php echo e(asset('js/fontawesome.min.js')); ?>"></script>

    <!-- Bootstrap App -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/Adminlte.min.js')); ?>"></script>

    <!-- Select 2 App -->
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        //Initialize Select2 Elements
        $('.select2').select2()

        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\myposs\resources\views/layouts/app.blade.php ENDPATH**/ ?>