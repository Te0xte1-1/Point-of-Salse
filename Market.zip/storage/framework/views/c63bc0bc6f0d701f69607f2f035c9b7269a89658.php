<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->cat_name); ?></td>
        <td><?php echo e($item->pro_name); ?></td>
        <td><?php echo e($item->batch_id); ?></td>
        <td><?php echo e($item->qty); ?></td>
        <td><?php echo e($item->unit_cost_price); ?></td>
        <td><?php echo e($item->total_cost_unit); ?></td>
        <td><?php echo e($item->risk); ?></td>
        <td>
            <?php if($item->expiration_date == ''): ?>
                بدون تاريخ إنتهاء
            <?php else: ?>
                <?php echo e($item->expiration_date); ?>

            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Market\resources\views/stock/get_product_by_cat.blade.php ENDPATH**/ ?>