

<?php $__env->startSection('content'); ?>
    <style>
        th,
        td {
            text-align: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            padding: 10px;
        }

        .row {
            padding-left: 10px;
            padding-right: 10px;
        }

        h2,
        h6 {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center !important;
        }

        label {
            float: right !important;
            margin-right: 15px;
        }
    </style>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('الحسابات')); ?>

                            <i class="fa fa-tree"></i>
                        </h4>

                        <p class="text-right">إضافة حساب جديد
                            <i class="fa fa-plus"></i>
                        </p>

                    </div>
                    <div class="card-body">

                        <!-- /.card-header -->
                        <!-- form start -->
                        <form action="<?php echo e(route('Accounts.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>رقم الحساب</label>
                                            <input type="number" disabled class="form-control" required name="acc_number"
                                                id="acc_number">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>اسم الحساب</label>
                                            <input type="text" class="form-control" required name="acc_name"
                                                id="acc_name">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="">نوع الحساب</label>
                                            <select name="acc_type" class="form-control" id="acc_type">
                                                <option value=""></option>
                                                <?php $__currentLoopData = $acc_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->account_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>هل الحساب اب</label>
                                            <select name="is_parent" class="form-control" id="is_parent">
                                                <option value=""></option>
                                                <option value="1">نعم</option>
                                                <option value="0">لا</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6" id="divparent" style="display: none">
                                        <div class="form-group">
                                            <label>الحساب الأب</label>
                                            <select name="parent" class="form-control" id="parent">
                                                <option value=""></option>
                                                <?php $__currentLoopData = $acc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>حالة رصيد أول المده </label>
                                            <select name="balance_status" class="form-control" id="balance_status">
                                                <option value=""></option>
                                                <option value="1">دائن</option>
                                                <option value="2">مدين</option>
                                                <option value="3">متزن</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>رصيد اول المده للحساب</label>
                                            <input type="number" class="form-control" required name="balance_start"
                                                id="balance_start">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>ملاحظات</label>
                                            <input type="text" class="form-control" required name="note"
                                                id="note">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>حالة التفعيل </label>
                                            <select name="active" class="form-control" id="active">
                                                <option value=""></option>
                                                <option value="1">مفعل</option>
                                                <option value="0">متوقف</option>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                <div class="card-footer">
                                    <input type="submit" class="form-control btn-success" value="حفظ البيانات">
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            var balance_status = $('#balance_status').val();
            var balance_start = $('#balance_start').val();
            $(document).on('change', '#is_parent', function() {
                if ($(this).val() == 0) {
                    $('#divparent').show();

                } else {
                    $('#divparent').hide();
                }
            });
            $(document).on('change', '#balance_status', function() {
                if ($(this).val() == 1) {
                    $('#balance_start').val('');
                    if (balance_start == '0') {
                        alert('يجب ان تكون قيمة هذا الحقل اكبر من الصفر');
                    }

                }
                if ($(this).val() == 2) {
                    $('#balance_start').val('');
                    if (balance_start == '0') {
                        alert('يجب ان تكون قيمة هذا الحقل اكبر من الصفر');
                    }
                }
                if ($(this).val() == 3) {
                    $('#balance_start').val(0);
                    if (balance_start > 0) {
                        alert('يجب ان تكون قيمة هذا الحقل صفر');
                    }
                }
            });

            // $(document).on('input', '#balance_start', function() {

            //     if (balance_status !== 0) {
            //         $('#balance_start').val('');
            //         alert('يجب عليك كتابة حالة الرصيد');
            //         $('#balance_status').focus();
            //         return false;
            //     }

            // });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Account_Tree/create.blade.php ENDPATH**/ ?>