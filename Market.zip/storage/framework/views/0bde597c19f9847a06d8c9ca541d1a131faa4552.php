
<?php $__env->startSection('title'); ?>
    Purshace Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        th,
        td {
            text-align: center;
        }

        .container {
            padding: 10px;

        }

        .row {
            padding-left: 10px;
            padding-right: 10px;
        }

        h2 {
            text-align: center !important;
            font-size: 18px;
        }
    </style>

    <div class="container-fluid">

        <div class="card card-primary card-outline">
            <div class="card-header">
                <h2>
                    صفحة فواتير المشتريات
                    <i class="fas fa-shopping-cart"></i>
                </h2>
                <a href="<?php echo e(route('Suppliers')); ?>" class=""> إضافة مورد جديد <i class="fa fa-user"></i></a>

                <a href="<?php echo e(route('Purshace.create')); ?>" class="btn btn-primary btn-sm"
                    style="margin-left:1035px;margin-bottom:10px;"> إضافة فاتورة جديده
                </a>
                <br>
                <div class="row">
                    <div class="row">
                        <input type="hidden" name="_token" value="kgXDQy9iqcm6UsbYNSqy8dRnPgHsDUDZyiJNBfuI">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="">كود الإيصــال</label>
                                <input type="text" class="form-control" name="cat_name" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="">بحث بالتاريخ من تاريخ</label>
                                <input type="text" class="form-control" name="cat_name" placeholder="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="">بحث بالمورد</label>
                                <input type="text" class="form-control" name="cat_name" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="">بحث بالتاريخ الى تاريخ</label>
                                <input type="text" class="form-control" name="cat_name" placeholder="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="">بحث بالمخزن</label>
                                <input type="text" class="form-control mt-1" name="cat_name" placeholder="">
                            </div>
                            <div class="form-group">
                                
                                <label for="">اكشن</label>
                                <button type="button" class="form-control mt-1 btn btn-success btn-sm mt-1" style="float: right" name=""
                                id="">بحث</button>    
                            </div>
                           
                        </div>
                        
                    </div>
                    <div class="col-sm-3">
                        
                    </div>
                    <div class="col-sm-3">
                     
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table id="dataTable" class="table table-bordered table-stripped table-hover">
                    <thead class="table table-secondary">
                        <th>كود الفاتــــــورة</th>
                        <th>اسم المورد</th>
                        <th>تاريخ الفاتورة</th>
                        <th>قيمة الفاتــــــورة</th>
                        <th>طريقة الدفع</th>
                        <th>الملاحظـــات</th>
                        <th>اكشن</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->auto_serial); ?></td>
                                <td><?php echo e($item->supplier_id); ?></td>
                                <td><?php echo e($item->order_date); ?></td>
                                <td><?php echo e($item->total_cost); ?></td>
                                <td>
                                    <?php if($item->order_pay_type == 1): ?>
                                    كاش
                                    <?php else: ?>
                                    أجل
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->note); ?></td>
                                <td>
                                    <?php if($item->is_approved == 1): ?>
                                        <a href="<?php echo e(route('Purshace.preview', $item->id)); ?>" title="عرض الفاتورة"
                                            class="btn btn-info btn-sm">

                                            <i class="fas fa-info"></i>
                                        </a>
                                    <?php else: ?>
                                        <a href="#"class="btn btn-primary btn-sm" value="<?php echo e($item->id); ?>"
                                            data-toggle="modal" data-target="#modal-xl"title="إعتماد الفاتورة">
                                            إعتماد
                                            <i class="fa fa-check"></i>
                                        </a>
                                        <a href="<?php echo e(route('Purshace.add_items', $item->id)); ?>"class="btn btn-secondary btn-sm"
                                            title="إضافة أصناف لهذه الفاتورة" value="<?php echo e($item->id); ?>">
                                            إضافة الأصناف
                                            <i class="fas fa-plus"></i>
                                        </a>

                                        <a href="<?php echo e(route('Purshace.edit', $item->id)); ?>" class="btn btn-success btn-sm"><i
                                                class="fa fa-edit"></i></a>
                                    <?php endif; ?>
                                </td>
                              
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
            <!-- /.card -->
        </div>
    </div>


    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/Adminlte.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {


            $('.add_row').click(function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                var cat_id = $(this).data('cat');
                var cat_name = $(this).data('cat_name');
                var product_name = $(this).data('product_name');
                var price = $(this).data('price');

                $(this).removeClass('btn-info').addClass('btn-default disabled');
                // alert(id + name + price);
                var $data =
                    `<tr>    
                <td>1</td>
                <td>
                    <label>${cat_name}
                    <input type="hidden" name="gogal" value="" class="total-price"/>
                    <input type="hidden" class="form-control" name="cat[]" value="${ cat_id }"/>
                    </td>
                <td>
                                                    <label>${product_name}
                    <input type="hidden" name="pro[]" class="form-control pro- ${  product_name }" value="${id}"/>
                    </td>
                    <td>
                        <input type="number"class="form-control" min="1" name="الكمية[]" data-price="${price}" value="" class="form-control product-الكمية" id="الكمية">
                        </td>
                        <td>
                            
                            <label>${price}
                            <input type="hidden"class="form-control" name="price[]" id="product-price"value="${price}"/>
                            </td>
                        <td>
                            <label name="" id="subtotall"/>
                        <input type="hidden"class="form-control" name="sub_total[]" id="subtotal" value="sub_total" />
            
                            </td>
                </form>
                    <td><button class="btn btn-danger btn-sm remove_row"data-id="${id}">-</button></td>
                </tr>`;
                $('#tboody').append($data);

                calc_total();

            }); //End Add Row


            $('body').on('change', '#cat', function(e) {

                var cat_id = $(this).val();
                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('load_purshace.load_pro_by_cat_id_in_purshace')); ?>",
                    data: {
                        cat_id: cat_id
                    },
                    success: function(data) {
                        console.log(data);
                    },
                });
            }); // Cat ID To Bring Pro Data


            $('.add_new_row').click(function(e) {
                e.preventDefault();
                alert(3);
            });
            $('body').on('click', '.disabled', function(e) {
                e.preventDefault();
            }); //End Disabled Click

            $('body').on('click', '.remove_row', function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                $('#product-' + id).removeClass('btn-default disabled').addClass('btn-info');
                $(this).closest('tr').remove();
                calc_total();

            }); // End Remove Row

            $('body').on('keyup change', '#الكمية', function() {
                var الكمية = parseInt($(this).val());
                var unitprice = $(this).data('price');
                $(this).closest('tr').find('#subtotal').val(الكمية * unitprice);
                $(this).closest('tr').find('#subtotall').html(الكمية * unitprice);
                calc_total();
            }); //End الكمية

            function calc_total() {
                var price = 0;
                $('#tboody #subtotall').each(function() {

                    price += parseInt($(this).html());
                });
                if (price > 0) {
                    $('#order-print').removeClass('btn-info disabled').addClass('btn-info');
                } else {
                    $('#order-print').addClass('btn-info disabled');
                }
                $('.total-price').html(price);
                $('.total-price').val(price);
            } // End Calc Total

            /////////////////////////////////////
            $('#toastsDefaultSuccess').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-success',
                    title: 'Purshace Invoice',
                    subtitle: 'Subtitle',
                    body: 'Your Purshace Has Been Successfully Completed .'
                })
            });

            // toastr

            /////////////////////////////////////

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/index.blade.php ENDPATH**/ ?>