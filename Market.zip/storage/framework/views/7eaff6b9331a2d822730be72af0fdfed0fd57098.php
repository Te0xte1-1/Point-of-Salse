<?php if($data == ''): ?>
    <option value="">القسم فارغ</option>
<?php else: ?>
    <select class="form-control select2 form-control-sm" name="pro_invoice" id="pro_invoice">
        <option value="0">اختر الصنف</option>
        <?php $__currentLoopData = $data->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pro_item->id); ?>" data-pro="<?php echo e($pro_item->product_name); ?>"><?php echo e($pro_item->product_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php endif; ?>



<?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/load_purshace/load_pro_by_cat_id_in_purshace.blade.php ENDPATH**/ ?>