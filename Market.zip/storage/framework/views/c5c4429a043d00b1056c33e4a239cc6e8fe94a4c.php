
<?php $__env->startSection('title'); ?>
    Print Invoice Salse A6
<?php $__env->stopSection(); ?>
<style>
    th,
    td {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        text-align: center !important;
    }

    .get_total {
        text-align: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: brown;
        font-weight: bold;
        font-size: 20px;
    }

    .invoice-col {
        margin-left: 450px !important;
        width: 200px !important;
        /* width: fit-content !important; */
        border: dashed 1px #000000;
    }

    @media print {
        @page {
            size: 105mm 8.5in !important;
        }

        td {
            font-size: 9px;

        }

        table {
            margin: 0;
        }

        .invoice-col {
            margin-left: 150px !important;
            /* width: fit-content !important; */
        }
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-12">
            <!-- Main content -->
            <div class="invoice p-3 mb-3">
                <!-- title row -->
                <div class="row">
                    <div class="col-12">
                        <h4 class="text-center">
                            <i class="fa fa-globe text-center"></i>
                            للحلول التقنية المتكاملة
                            [ IP-Magix ]
                            شركة
                        </h4>

                    </div>
                    <!-- /.col -->
                </div>
                <!-- info row -->
                <!-- /.col -->
                <?php if(!empty($salse->serial)): ?>


                    <div class="col-sm-12 invoice-col text-center">
                        <b>رقم الفاتــــــورة / #<?php echo e($salse->serial); ?></b>
                        <br>
                        <b>التـــاريخ/ 2/10/2014</b>
                        <br>
                        4F3S8J
                        <b>/ رقم الطلب</b>
                        <br>
                        <b>تاريخ السداد /</b> 2/22/2014<br>
                        <b>رقم حساب العميل /</b> 968-34567
                    </div>
                    <!-- /.col -->
            </div>
            <div class="row">
                <table id="dataTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>المنتجات</th>
                            <th>الكمية</th>
                            <th>سعر الوحدة</th>
                            <th>اجمالي الصنف</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $salse_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                                
                                <td><?php echo e($item->product_id); ?></td>
                                <td><?php echo e($item->qty); ?></td>
                                <td><?php echo e($item->price); ?></td>
                                <td><?php echo e($item->subtotal); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5" class="get_total">إجمالي الفاتورة
                                (5,0000.00)</td>
                        </tr>
                    </tbody>
                </table>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
    <?php else: ?>
        لا توجد داتا
        <?php endif; ?>
        <!-- /.invoice -->
    </div><!-- /.col -->
</div><!-- /.container -->


<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<!-- AdminLTE App -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<!-- AdminLTE App -->
<script src="<?php echo e(asset('js/Adminlte.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        // window.print();
    });
</script>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Prints/Salse/Print_A6.blade.php ENDPATH**/ ?>