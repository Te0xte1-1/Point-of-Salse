

<?php $__env->startSection('title'); ?>
    Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">الضبط العام</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Treasures')); ?>">بيانات الخزن</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('بيانات جميع الخزن')); ?>

                        </h4>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="dataTable" class="table table-bordered">
                            <thead>
                                <th>ID</th>
                                <th>اسم الخزينة</th>
                                <th>هل الخزينة رئيسية</th>
                                <th>أخر إيصال صرف</th>
                                <th>أخر إيصال تحصيل</th>
                                <th>حالة تفعيل الخزينة</th>
                                <th>اكشن</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $treasures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->treasures_name); ?></td>
                                        <td>
                                            <?php if($item->is_master == 1): ?>
                                                خزنة رئيسية
                                            <?php else: ?>
                                                خزنة فرعية
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->last_isal_exchange); ?></td>
                                        <td><?php echo e($item->last_isal_collect); ?></td>
                                        <td>
                                            <?php if($item->active == 1): ?>
                                                الخزنة مفعله
                                            <?php else: ?>
                                                الخزنة غير مفعله
                                            <?php endif; ?>
                                        </td>
                                        <td><a href="<?php echo e(route('Treasures.edit', $item->id)); ?>"><i
                                                    class="fa fa-edit"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                            </tbody>
                        </table>


                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Treasures/index.blade.php ENDPATH**/ ?>