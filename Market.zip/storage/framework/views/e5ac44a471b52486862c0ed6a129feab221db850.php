

<?php $__env->startSection('title'); ?>
    الترحيل بين المخازن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }h6{
            text-align: center;
            font-size: 14px;
        }
    </style>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">ضبط المخازن</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Stock')); ?>">الأقسام</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('الترحيل بين المخازن')); ?>

                        </h4>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <hr>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <h6>المخزن المرحل</h6>
                                    <select name="" id="" class="form-control">
                                        <option value=""></option>
                                        <?php $__currentLoopData = $Stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->stock_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <h6>الصنف المراد ترحيله</h6>
                                    <select name="" id="" class="form-control">
                                        <option value=""></option>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->stock_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <h6>الكمية المتوفرة في المخزن</h6>
                                    <input type="number" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <h6>المخزن الذي سيستلم البضاعه</h6>
                                    <select name="" id="" class="form-control">
                                        <option value=""></option>
                                        <?php $__currentLoopData = $Stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->stock_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <h6>الكمية المراد ترحيلها</h6>
                                    <input type="number" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <h4 class="text-center">تفاصيل البـيـــــان </h4>
                                <input type="number" style="background:lightyellow" class="form-control" name=""
                                    id="">
                            </div>
                            <div align="center">

                                <button class="btn btn-success btn-sm" style="background: #0f2e55; color:#fff; font-family:Arial, Helvetica, sans-serif"> ترحيل البضاعه</button>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.card-body -->



            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Send_Between_Stocks/index.blade.php ENDPATH**/ ?>