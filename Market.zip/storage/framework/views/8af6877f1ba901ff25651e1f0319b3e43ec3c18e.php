

<?php $__env->startSection('title'); ?>
    Admins
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">ضبط الصلاحيات</li>
            </li>
            <li class="breadcrumb-item active"><a href="#">شفتات الخزن</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h6 class="text-center">
                            <?php echo e(__('بيانات شفتات الخزن للمستخدمين')); ?>

                            <i class="fa fa-user"></i>
                        </h6>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="card card-success card-outline">
                                    <div class="card-header">
                                        <h4 class="text-center">
                                            <?php echo e(__('استلام خزنة لشفت جديد')); ?>

                                        </h4>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <!-- form start -->
                                        <form action="<?php echo e(route('Admins_Shifts.store')); ?>" method="POST">
                                            <div class="row">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <?php if(@isset($shift_data) && !@empty($shift_data)): ?>
                                                            <?php if($shift_data->admin_id == 1 && $shift_data->is_finished == 0): ?>
                                                                <label for="">لقد تم افتتاح الشفت فعلا </label>
                                                            <?php else: ?>
                                                                <label for="">بيانات الخزن المضافة
                                                                    لصلاحياتي</label>
                                                                <select name="treasures_id" class="form-control"
                                                                    id="treasures_id">
                                                                    <option value="">من فضلك قم بإختيار الخزنة
                                                                        لبدء
                                                                        الشفت
                                                                    </option>
                                                                    <?php $__currentLoopData = $treasures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($item->id); ?>">
                                                                            <?php echo e($item->treasures_name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <br>
                                                                <br>
                                                                <input type="submit"
                                                                    class="form-control btn-success btn-sm"
                                                                    value="بدأ الشفت">
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            لا توجد بيانات لعرضها
                                                        <?php endif; ?>

                                                    </div>
                                                </div>

                                            </div>
                                        </form>

                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-12 col-md-6">
                                <div class="card card-info card-outline">
                                    <div class="card-header">
                                        <h4 class="text-center">
                                            <?php echo e(__(' بيانات الشفت المفتوح حاليا')); ?>

                                        </h4>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <!-- form start -->
                                        <form action="<?php echo e(route('Admins_Shifts.close_shift')); ?>" method="POST">
                                            <div class="row">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <div class="data-shift-opened">
                                                            <?php if(@isset($shift_data) && !@empty($shift_data)): ?>
                                                                <?php if($shift_data->admin_id == 1 and $shift_data->is_finished == 1): ?>
                                                                    <label for="">لا يوجد شفت فاتح يمكنك بدأ شفت
                                                                        جديد</label>
                                                                <?php else: ?>
                                                                    <h6 for="">اسم المستخدم
                                                                        <span style="font-size: 14px;color:blue"> (
                                                                            <?php echo e($shift_data->admin_id); ?> )</span>
                                                                    </h6>
                                                                    <h6>الخزنةالمستخدمة في الشفت
                                                                        <span style="font-size: 14px;color:blue">(
                                                                            <?php echo e($shift_data->treasures_id); ?> )</span>
                                                                    </h6>
                                                                    <h6>تاريخ بدايةالشفت
                                                                        <span style="font-size: 14px;color:blue">(
                                                                            <?php echo e($shift_data->started_date); ?> )</span>
                                                                    </h6>
                                                                    <input type="submit"
                                                                        class="form-control btn-info btn-sm"
                                                                        value="إقفال الشفت الحالي">
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                لا توجد داتا
                                                            <?php endif; ?>



                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </form>

                                    </div>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table id="dataTable" class="table table-bordered table-hover table-stripped">
                                    <thead>
                                        <th>كود الشفت</th>
                                        <th>اسم المستخدم</th>
                                        <th>اسم الخزنة</th>
                                        <th>وقت فتح الشفت</th>
                                        <th>حاله الشفت</th>
                                        <th>حاله مراجعه الشفت</th>
                                        <th>اكشن</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $admins_shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->admin_id); ?></td>
                                                <td><?php echo e($item->treasures_id); ?></td>
                                                <td><?php echo e($item->started_date); ?></td>
                                                <td><?php echo e($item->is_finished); ?></td>
                                                <td><?php echo e($item->is_delevered_and_reviewed); ?></td>
                                                <td>
                                                    <a href="#" class="btn btn-success btn-sm">طباعة الكشف</a>
                                                    <a href="#" class="btn btn-danger btn-sm">كشف مختصر</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Admins_Shifts/index.blade.php ENDPATH**/ ?>