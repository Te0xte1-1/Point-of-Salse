
<?php $__env->startSection('title'); ?>
    الأصناف
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        body {
            direction: rtl !important;
        }

        label {
            text-align: center !important;
        }

        #photo_pro {
            border: 1px solid rgba(34, 33, 33, 0.251);
            border-radius: 8px;
            width: 300px;
            height: 200px;
            padding: 10px;
            background: #ddd;
        }

        th,
        td {
            font-size: 14px;
            text-align: center;
        }
    </style>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Dashboard')); ?>">ضبط المخازن</a></li>
            <li class="breadcrumb-item">الأصناف</li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('الأصــنــاف')); ?>

                        </h4>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <a href="<?php echo e(route('Product.create')); ?>" class="btn btn-default">
                                    اضاف صنف جديد
                                </a>

                            </div>

                        </div>
                        <hr>
                        <div class="col-sm-12">
                            <table id="dataTable" class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>اسم القسم</th>
                                        <th>اسم الصنف</th>
                                        <th>سعر الشراء</th>
                                        <th>سعر البيع</th>
                                        <th>الكمية الموجوده في المخزن</th>
                                        <th>حد الصرف</th>
                                        <th>صورة الصنف</th>
                                        <th>تاريخ الإنتهاء</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e($item->category_id); ?></td>
                                            <td><?php echo e($item->product_name); ?></td>
                                            <td><?php echo e($item->purshace_price); ?></td>
                                            <td><?php echo e($item->price); ?></td>
                                            <td><?php echo e($item->stock); ?></td>
                                            <td><?php echo e($item->risk); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset('images/' . $item->photo)); ?>" width="100" height="70" alt=""
                                                    srcset="">
                                            </td>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <td><a href="#" class="btn btn-info btn-sm" data-toggle="modal"
                                                    data-target="#modal-xl-edit-product">Edit</a><a href=""
                                                    class="btn btn-danger btn-sm ml-1">Delete</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            <div class="modal fade" id="modal-xl-edit-product">
                                <div class="modal-dialog modal-xl">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Default Modal</h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('Product.store')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label for="">Category</label>
                                                                <select name="category_id" class="form-control"
                                                                    id="">
                                                                    <option value=""></option>
                                                                    
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">اسم الصنف</label>
                                                                <input type="text" class="form-control" required
                                                                    name="product_name" id="exampleInputEmail1">

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">وصف الصنف
                                                                </label>
                                                                <input type="text" class="form-control" required
                                                                    name="product_description" id="exampleInputEmail1">
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-4">
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">سعر الشراء
                                                                </label>
                                                                <input type="number" class="form-control" required
                                                                    name="purshace_Price" id="exampleInputEmail1">
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-4">
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">
                                                                    سعر البيع</label>
                                                                <input type="number" class="form-control" required
                                                                    name="Price" id="exampleInputEmail1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">الكمية المراد اضافتها
                                                                    للمخزن</label>
                                                                <input type="number" class="form-control" required
                                                                    name="stock" id="exampleInputEmail1">
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">حد الصرف للصنف</label>
                                                                <input type="number" class="form-control" required
                                                                    name="risk" id="exampleInputEmail1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                        </div>
                                        <div class="modal-footer justify-content-between">
                                            <button type="button" class="btn btn-default"
                                                data-dismiss="modal">إغلاق</button>
                                            <button type="submit" class="btn btn-primary btn-sm">تأكيد</button>
                                        </div>
                                        </form>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Product/index.blade.php ENDPATH**/ ?>