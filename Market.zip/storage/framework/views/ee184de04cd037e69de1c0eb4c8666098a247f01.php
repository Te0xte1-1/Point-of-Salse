

<?php $__env->startSection('title'); ?>
    Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        td {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 18px !important;
            font-weight: bold;
        }
    </style>
    <div class="container-fluid">

        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header text-right">
                        <h6 class="text-center">
                            <?php echo e(__('رصيد الخزن')); ?>


                        </h6>
                    </div>




                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-bordered">
                                <thead>
                                    <th>البيان</th>
                                    <th>المبلغ</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $treasures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      
                                        <tr>
                                            <td style="background-color:#b81818;color:#fff">
                                                المصروفات
                                            </td>
                                            <td style="text-align: center;background-color:#186;color:#fff">
                                                <?php echo e($item->Total); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="background-color:#2ba31b;color:#fff">
                                                الإيرادات
                                            </td>
                                            <td style="text-align: center;background-color:#186;color:#fff">
                                                <?php echo e($item->Total); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="background-color:#065818;color:#fff">
                                                المبيعات
                                            </td>
                                            <td style="text-align: center;background-color:#186;color:#fff">
                                                <?php echo e($salse_total); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="background-color:#680a0a;color:#fff">
                                                المشتريات
                                            </td>
                                            <td style="text-align: center;background-color:#186;color:#fff">
                                                <?php echo e($purshace_total); ?>

                                            </td>
                                        </tr>
                                      
                                        <tr>
                                            <td style="background-color:#a9ac0c;color:#fff">
                                                <?php echo e($item->treasures_name); ?>

                                            </td>
                                            <td style="text-align: center;background-color:#186;color:#fff">
                                                <?php echo e($item->Total); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Treasures_Balance/index.blade.php ENDPATH**/ ?>