<?php if($data == ''): ?>
    <option value="">القسم فارغ</option>
<?php else: ?>
    <select class="form-control form-control-sm" name="item" id="item">
        <option>اختر الصنف</option>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pro_item->id); ?>" data-pro="<?php echo e($pro_item->product_name); ?>"><?php echo e($pro_item->product_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php endif; ?>



<?php /**PATH C:\xampp\htdocs\Market\resources\views/Salse/load_salse/load_product_by_serial.blade.php ENDPATH**/ ?>