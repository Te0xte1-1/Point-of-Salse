

<?php $__env->startSection('content'); ?>
    <style>
        th,
        td {
            text-align: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            padding: 10px;
        }

        .row {
            padding-left: 10px;
            padding-right: 10px;
        }

        h2,
        h6 {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center !important;
        }

        label {
            float: right !important;
            margin-right: 15px;
        }
    </style>
    <div class="container">
        
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('العمــلاء')); ?>

                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="card-header">
                            <p class="text-center">إضافة عميل جديد</p>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <!-- form start -->
                            <form action="<?php echo e(route('Suppliers.store')); ?>" method="POST">
                                <div class="row">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="">كود الفاتورة</label>
                                            <input type="text" class="form-control" name="cat_name" placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="">بحث بالعميل</label>
                                            <input type="text" class="form-control" name="cat_name" placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="">بحث بفئة الفاتــــــورة</label>
                                            <input type="text" class="form-control" name="cat_description"
                                                placeholder="">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="">بحث بنوع الفاتــــــورة</label>
                                            <input type="text" class="form-control" name="cat_name" placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="">بحث بنوع الخصم</label>
                                            <input type="text" class="form-control" name="cat_description"
                                                placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="">بحث بالتاريخ من تاريخ</label>
                                            <input type="text" class="form-control" name="cat_name" placeholder="">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="">بحث بنوع الإعتماد</label>
                                            <input type="text" class="form-control" name="cat_name" placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="">بحث</label>
                                            <input type="text" class="form-control" name="cat_description"
                                                placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="">بحث بالتاريخ إلى تاريخ</label>
                                            <input type="text" class="form-control" name="cat_name" placeholder="">
                                        </div>
                                    </div>
                                    <input type="submit" class="form-control btn-success btn-sm" value="بحث">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Customers/create.blade.php ENDPATH**/ ?>