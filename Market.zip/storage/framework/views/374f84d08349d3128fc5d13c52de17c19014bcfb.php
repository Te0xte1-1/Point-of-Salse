<?php $__currentLoopData = $Suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><a href="<?php echo e(route('Purshace.preview',$item->id)); ?>" ><?php echo e($item->auto_serial); ?></a></td>
    <td><a href="<?php echo e(route('Purshace.preview',$item->id)); ?>" >
        <?php if($item->supplier_id == 0): ?>بدون عميل
        <?php else: ?>
        <?php echo e($item->supplier_id); ?>

        <?php endif; ?>
       </a>
    </td>
    <td><a href="<?php echo e(route('Purshace.preview',$item->id)); ?>" ><?php echo e($item->order_date); ?></a></td>
    <td><a href="<?php echo e(route('Purshace.preview',$item->id)); ?>" ><?php echo e($item->total_cost); ?></a></td>
    <td>
        <?php if($item->is_approved == 1): ?>
        <a href="<?php echo e(route('Purshace.preview',$item->id)); ?>" >فاتورة معتمدة</a>
        <?php else: ?>
        فاتورة مفتوحه
        <?php endif; ?>
    </td>
    <td>
        <?php if($item->order_pay_type == 1): ?>
            كاش
        <?php else: ?>
            أجل
        <?php endif; ?>
    </td>
    <td><?php echo e($item->note); ?></td>
    <td>
        <?php if($item->is_approved == 1): ?>
            <a href="<?php echo e(route('Purshace.preview', $item->id)); ?>" title="عرض الفاتورة"
                class="btn btn-info btn-sm">

                <i class="fas fa-info"></i>
            </a>
        <?php else: ?>
            
            <a href="<?php echo e(route('Purshace.add_items', $item->id)); ?>"class="btn btn-secondary btn-sm"
                title="إضافة أصناف لهذه الفاتورة" value="<?php echo e($item->id); ?>">
                فاتورة مفتوحه                 
            </a>

            <a href="<?php echo e(route('Purshace.edit', $item->id)); ?>" class="btn btn-success btn-sm"><i
                    class="fa fa-edit"></i></a>
        <?php endif; ?>
    </td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Purshace/load_purshace/load_table_index.blade.php ENDPATH**/ ?>