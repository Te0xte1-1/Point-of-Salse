<h1>
    test
</h1><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/Purshace.blade.php ENDPATH**/ ?>