<?php $__currentLoopData = $get_items_from_order_bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->order_id); ?></td>
        <td><?php echo e($item->item_id); ?></td>
        <td><?php echo e($item->item_qty); ?></td>
        <td><?php echo e($item->unit_price); ?></td>
        <td id="td_total_price"><?php echo e($item->total_price); ?></td>
        <td>
            <a href="#"class="btn btn-warning btn-sm" data-id="<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" 
                id="modal-xl-edit_items">
                <i class="fas fa-edit"></i>
                <a href="#" value="<?php echo e($item->id); ?>" class="btn btn-danger btn-sm m-1">
                    <i class="fa fa-trash"></i>
                </a>

        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/load_purshace/items_added_done.blade.php ENDPATH**/ ?>