

<?php $__env->startSection('title'); ?>
    Admins
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header text-right">
                        <h6 class="text-center">
                            <?php echo e(__('بيانات شفتات الخزن للمستخدمين')); ?>

                            <i class="fa fa-user"></i>
                        </h6>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                    
                            <div class="col-sm-12 col-md-6">
                                <div class="card card-info card-outline">
                                    <div class="card-header text-right">
                                        <h4 class="text-center">
                                            <?php echo e(__(' بيانات الشفت المفتوح حاليا')); ?>

                                        </h4>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <!-- form start -->
                                        <form action="<?php echo e(route('Admins_Shifts.close_shift')); ?>" method="POST">
                                            <div class="row">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <div class="data-shift-opened">
                                                            <?php if(@isset($shift_data) && !@empty($shift_data)): ?>
                                                                <?php if($shift_data->admin_id == 1 and $shift_data->is_finished == 1): ?>
                                                                    <label >لا يوجد شفت فاتح يمكنك بدأ شفت
                                                                        جديد</label>
                                                                <?php else: ?>
                                                                    <h6 >اسم المستخدم
                                                                        <span style="font-size: 14px;color:blue"> (
                                                                            <?php echo e($shift_data->admin_id); ?> )</span>
                                                                    </h6>
                                                                    <h6>الخزنةالمستخدمة في الشفت
                                                                        <span style="font-size: 14px;color:blue">(
                                                                            <?php echo e($shift_data->treasures_id); ?> )</span>
                                                                    </h6>
                                                                    <h6>تاريخ بدايةالشفت
                                                                        <span style="font-size: 14px;color:blue">(
                                                                            <?php echo e($shift_data->started_date); ?> )</span>
                                                                    </h6>
                                                                    <input type="submit"
                                                                        class="form-control btn-info btn-sm"
                                                                        value="إقفال الشفت الحالي">
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                لا توجد داتا
                                                            <?php endif; ?>



                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </form>

                                    </div>
                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table id="dataTable" class="table table-bordered table-hover table-stripped">
                                    <thead>
                                        <th>كود الشفت</th>
                                        <th>اسم المستخدم</th>
                                        <th>اسم الخزنة</th>
                                        <th>وقت فتح الشفت</th>
                                        <th>حاله الشفت</th>
                                        <th>حاله مراجعه الشفت</th>
                                        <th>اكشن</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $admins_shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->admin_id); ?></td>
                                                <td><?php echo e($item->treasures_id); ?></td>
                                                <td><?php echo e($item->started_date); ?></td>
                                                <td><?php echo e($item->is_finished); ?></td>
                                                <td><?php echo e($item->is_delevered_and_reviewed); ?></td>
                                                <td>
                                                    <a href="#" class="btn btn-success btn-sm">طباعة الكشف</a>
                                                    <a href="#" class="btn btn-danger btn-sm">كشف مختصر</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Admins_Shifts/index.blade.php ENDPATH**/ ?>