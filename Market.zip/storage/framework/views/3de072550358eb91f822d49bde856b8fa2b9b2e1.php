

<?php $__env->startSection('content'); ?>
    <style>
        th,
        td {
            text-align: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            padding: 10px;
        }

        .row {
            padding-left: 10px;
            padding-right: 10px;
        }

        h2,
        h6 {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center !important;
        }

        label {
            float: right !important;
            margin-right: 15px;
        }
    </style>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header text-right">
                        <h4 class="text-center">
                            <?php echo e(__('العمليات على الخزينة')); ?>

                            <i class="fa fa-tree"></i>
                        </h4>

                    </div>
                    <div class="card-body">

                        <!-- /.card-header -->
                        <div class="card-body">
                            <table dir="rtl" border="1"
                                style="width: 98%;margin-bottom:35px;float: right;text-align:center; border:1px solie #000"cellcpacing="0"
                                cellpadding="1">
                                <thead>
                                    <tr>
                                        <td colspan="5"style="background-color:#939c9c;">تفاصيل الحركات المالية على
                                            الخزينة الرئيسية</td>
                                    </tr>

                                    <tr style="background-color:#ddd;">
                                        <td>رقم الحركة</td>
                                        <td>تاريخ الحركة</td>
                                        <td>نوع الحركة</td>
                                        <td>المبلغ</td>
                                        <td>مراجعه الحركة</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $Treasures_trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td><?php echo e($item->isal_number); ?></td>
                                            <td><?php echo e($item->date); ?></td>
                                            <td><?php echo e($item->move_type_name); ?></td>
                                            <td><?php echo e($item->money); ?></td>
                                            <td><a href="<?php echo e(route('Cat', $item->id)); ?>"></a><i class="fa fa-edit"></i></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Treasures/edit.blade.php ENDPATH**/ ?>