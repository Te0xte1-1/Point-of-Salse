

<?php $__env->startSection('title'); ?>
    Customers
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">ضبط المخازن</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Cat')); ?>">العملاء</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">

                            <?php echo e(__('الــعمـــلاء')); ?>

                        </h4>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                      
                                    <a href="<?php echo e(route('Customers.create')); ?>" class="btn btn-primary btn-sm">
                                        اضافه عميل جديد
                                </a>

                                    
                       

                        </div>
                        <hr>
                        <div class="col-sm-12">
                            <table id="dataTable" class="table table-bordered table-striped " aria-describedby="example1_info">
                                <thead>
                                    <tr>
                                        <th >
                                            اسم العميل</th>
                                        <th >
                                            وصف العميل</th>
                                        <th >
                                            Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $Customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td>
                                                <?php echo e($item->cat_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->cat_description); ?>

                                            </td>
                                            <td>
                                                <a href="Cat/edit/<?php echo e($item->cat_description); ?>" id="cat_edit"
                                                    class="btn btn-info btn-sm" data-toggle="modal"
                                                    data-target="#modal-cat_edit">Edit</a>
                                                <a href="Cat/delete/<?php echo e($item->cat_description); ?>" id="cat_delete"
                                                    class="btn btn-danger btn-sm">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card-body -->


                    
                    <div class="modal fade" id="modal-cat_edit">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Default Modal</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('Customers.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">اسم العميل</label>
                                                    <input type="text" value="<?php echo e($item->cat_name); ?>"
                                                        class="form-control" name="cat_name" id="exampleInputEmail1">
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">وصف العميل</label>
                                                    <input type="text" value="<?php echo e($item->cat_description); ?>"
                                                        class="form-control" name="cat_description"
                                                        id="exampleInputEmail1">
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <button type="button" class="btn btn-default"
                                                    data-dismiss="modal">إغلاق</button>
                                                <button type="submit" class="btn btn-primary btn-sm">تأكيد</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Customers/index.blade.php ENDPATH**/ ?>