

<?php $__env->startSection('title'); ?>
    إيصال استلام النقدية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .wrapper {
            background: #f0efef;
        }

        #ISAL {
            background: #fff;
            border: 1px solid #29252542;
            font-family: sans-serif;
            border-radius: 8px;
            margin-left: 15px;
            margin-right: 15px;
            height: 410px;
            padding: 10px;
        }

        h6 {
            text-align: center;
            color: #000;
            font-size: 14px !important;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
        }
    </style>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
            <li class="breadcrumb-item active"> <a href="<?php echo e(route('Quick_access')); ?>">الرئيسية</a></li>
            <li class="breadcrumb-item active">الحسابات والنقدية</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Esal_Srf_Mony')); ?>">إيصال صرف النقدية</a></li>
            <li class="breadcrumb-item active">عرض</li>
        </ol>

        <div class="nagdia" id="ISAL">

            <h5 style="text-align:center">
                ايصال صرف نقدية جديد
                <i class="fa fa-flag"></i>
            </h5>
            <hr>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <h6>تاريخ الحركة

                        </h6>
                        <input type="date" name="date" id="date" class="form-control form-control-sm">
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <h6>الحسابات المالية</h6>
                        <select name="accounts" id="accounts" class="form-control form-control-sm">
                            <option value="">اختر الحساب المالي</option>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-acc_type="<?php echo e($item->account_type); ?>" value="<?php echo e($item->account_number); ?>">
                                    <?php echo e($item->name); ?> ( <?php echo e($item->account_type_name); ?> )</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group ">
                        <h6>نوع الحركة المالية</h6>
                        <select name="money_move" id="money_move" class="form-control form-control-sm">
                            <option value="">اختر نوع الحركة المالية</option>
                            <?php $__currentLoopData = $mony_type_move; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->mony_move_type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <h6>الخذنه التي سيتم فيها الصرف
                        </h6>
                        <select name="treasures" id="treasures" class="form-control form-control-sm">
                            <option value=""></option>
                            <?php $__currentLoopData = $Treasures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->treasures_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <h6>الرصيد المتاح بالخزنة</h6>
                        <input type="number" name="available_balance" value="<?php echo e($total_amount_of_treasures); ?>" disabled
                            style="text-align: center;" id="available_balance" class="form-control form-control-sm">
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <h6>قيمة المبلغ المتحصل</h6>
                        <input type="number" name="amount" id="amount" class="form-control form-control-sm">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <h6>تفاصييل البيـــــان</h6>
                <textarea name="note" style="color:#000;border:1px solid #ddd;margin-left:30px;" cols="137" rows="4"
                    placeholder="تفاصييل البيـــــان"></textarea>
            </div>
            <button type="button" id="srf_done" class="form-control btn-info" value="">صرف</button>

        </div>
        <hr>
        <div class="row">
            <input type="hidden" name="_token" value="kgXDQy9iqcm6UsbYNSqy8dRnPgHsDUDZyiJNBfuI">
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="">كود الإيصــال</label>
                    <input type="text" class="form-control" name="cat_name" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">بحث بالعميل</label>
                    <input type="text" class="form-control" name="cat_name" placeholder="">
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="">بحث بنوع الخصم</label>
                    <input type="text" class="form-control" name="cat_description" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">بحث بالتاريخ من تاريخ</label>
                    <input type="text" class="form-control" name="cat_name" placeholder="">
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="">بحث بنوع الإعتماد</label>
                    <input type="text" class="form-control" name="cat_name" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">بحث بالتاريخ إلى تاريخ</label>
                    <input type="text" class="form-control" name="cat_name" placeholder="">
                </div>
            </div>
            <input type="submit" class=" btn-success btn-sm" value="بحث">
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-12">
                <table id="dataTable" class="table table-bordered table-hover ">
                    <thead class="table-dark">
                        <th>#</th>
                        <th>رقم الإيصال</th>
                        <th>الخزينة</th>
                        <th>المبلغ الذي تم تحصيله</th>
                        <th>نوع الحركة</th>
                        <th>البيـــــان</th>
                        <th>تاريخ العملية</th>
                        <th>اكشن</th>
                    </thead>
                    <tbody>
                        <tr>
                            <?php $__currentLoopData = $Treasures_trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td> <?php echo e($item->id); ?> </td>
                                <td> <?php echo e($item->isal_number); ?> </td>
                                <td> <?php echo e($item->treasures_id); ?> </td>
                                <td> <?php echo e($item->money * -1); ?> </td>
                                <td> <?php echo e($item->move_type_id); ?> </td>
                                <td> <?php echo e($item->note); ?> </td>
                                <td> <?php echo e($item->created_at); ?> </td>
                                <td>

                                    <a href="<?php echo e(route('Esal_Recive_Mony', $item->id)); ?>"><i class="fa fa-print"
                                            style="color:rgb(17, 50, 80); margin:5px"></i></a>
                                    <a href="<?php echo e(route('Esal_Recive_Mony', $item->id)); ?>"><i class="fa fa-info"></i></a>

                                </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- /.card-body -->


        <!-- jQuery -->
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

        <script>
            $(document).ready(function() {


                $(document).on('click', '#srf_done', function(e) {
                    e.preventDefault();
                    var srf_money_form = $('#srf_money_form').serialize();
                    var date = $('#date').val();
                    var accounts = $('#accounts').val();
                    var money_move = $('#money_move').val();
                    var treasures = $('#treasures').val();
                    var available_balance = $('#available_balance').val();
                    var amount = $('#amount').val();
                    var note = $('#note').val();

                    $.ajax({
                        method: 'post',
                        url: "<?php echo e(route('Esal_Srf_Mony.store')); ?>",
                        data: {
                            date: date,
                            accounts: accounts,
                            money_move: money_move,
                            treasures: treasures,
                            available_balance: available_balance,
                            amount: amount,
                        },
                        success: function(data) {
                            alert('تمت العملية بنجاح');

                            var accounts = $('#accounts').val("");
                            var money_move = $('#money_move').val("");
                            var treasures = $('#treasures').val("");
                            var amount = $('#amount').val("");
                            var note = $('#note').val("");
                        },
                    });


                });

        
                $(document).on('keyup change', '#money_move', function(e) {

                    var accounts = $('#accounts').val();
                    if (accounts == "") {
                        alert("يجب عليك اختيار نوع الحساب");
                    }
                    $(this).val("");
                });
                $(document).on('keyup change', '#treasures', function(e) {
                    var money_move = $('#money_move').val();
                    if (money_move == "") {
                        alert("يجب عليك اختيار نوع الحركة المالية");
                    }
                    $(this).val("");
                });
                $(document).on('keyup change', '#amount', function(e) {

                    var treasures = $('#treasures').val();
                    if (treasures == "") {
                        alert("يجب عليك اختيار الخزنة");

                        $(this).val("");
                    }

                });





                // function sort_move_type() {
                $(document).on('change', '#accounts', function(e) {
                    var ac_type = $(this).val();
                    if (ac_type == "") {
                        $('#money_move').val("");
                    }
                });
                // }
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Esal_Srf_Mony/index.blade.php ENDPATH**/ ?>