
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-warning card-outline">
                    <div class="card-header ">
                        <b>
                            <h5 class="text-center">تعديل فاتورة مبيعات</h5>

                            <hr>


                        </b>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                            
                            <input type="hidden" name="_token" value="x8wS8Ymxan8ZrT0QaMNNo1jOHEbHAJrHoatwGqtJ">
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>
                                            <i class="far fa-calendar-alt"></i>
                                            التـــاريخ
                                        </h6>

                                        <input type="date" name="date" class="form-control form-control-sm"
                                            id="date">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        بيانات العميل
                                        <i class="fa fa-user"></i></h6>
                                        <input type="text" class="form-control form-control-sm" value="<?php echo e($bill_salse_info->account_number); ?>"  name=""
                                            id="">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>رقم الفاتورة <i class="fa fa-barcode"></i></h6>
                                        <input type="text" value="<?php echo e($bill_salse_info->serial); ?>" name="serial" disabled
                                            style="background:lightyellow;color:#000;text-align:center"
                                            class="form-control form-control-sm" id="">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>نوع الفاتورة <i class="fa fa-barcode"></i></h6>

                                        <input type="text" class="form-control form-control-sm" value="<?php echo e($bill_salse_info->account_number); ?>" name=""
                                            id="">
                                    </div>
                                </div>

                            </div>
                            <hr style="border:1px solid #ddff00">
                        </div>


                        <h6 style="text-align: center">الأصناف المضافة للفاتورة</h6>
                        <hr style="border:1px solid #ddff00">
                        <div class="row">
                            <div class="col-sm-12">
                                <table id="example2" class="table table-hover table-bordered table-stripped"
                                    aria-describedby="example2_info">
                                    <thead class="table table-bordered table-warning">
                                        <tr>
                                            <th width="2%">ID</th>
                                            <th width="2%">المخزن</th>
                                            <th width="13%">القسم</th>
                                            <th width="13%">اسم الصنف</th>
                                            <th width="13%">وحدة البيع</th>
                                            <th width="7%">الكمية</th>
                                            <th width="15%x">السعر</th>
                                            <th width="15%x">الإجمالي</th>

                                        </tr>
                                    </thead>
                                    <tbody id="tboody">
                                        <?php $__currentLoopData = $bill_salse_detailse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->store); ?></td>
                                                <td><?php echo e($item->category_id); ?></td>
                                                <td><?php echo e($item->product_id); ?></td>
                                                <td><?php echo e($item->unit_id); ?></td>
                                                <td><?php echo e($item->qty); ?></td>
                                                <td><?php echo e($item->price); ?></td>
                                                <td><?php echo e($item->subtotal); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                                <hr style="border:1px solid #ddff00">
                                <br>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <h6>
                                                إجمالي الأصناف
                                            </h6>
                                            <input type="text" name="" id=""
                                                class="form-control form-control-sm" disabled min="0" value="0"
                                                style="background:lightyellow;color:#000;text-align:center">
                                        </div>

                                        <div class="form-group">
                                            <h6>
                                                خزنة التحصيل
                                            </h6>
                                            <select name="" id="" class="form-control form-control-sm"style="background:lightyellow;color:#000;text-align:center">
                                                <option value="0">الخزنة الرئيسية</option>
                                                <option value="1">الخزنة الفرعيه</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <h6>
                                                نسبة الضريبة
                                            </h6>
                                            <input type="text" name="" id=""
                                                class="form-control form-control-sm"style="background:lightyellow;color:#000;text-align:center">
                                        </div>
                                        <div class="form-group">
                                            <h6>
                                                المبلغ المراد خصمة
                                            </h6>
                                            <input type="text" name="" id=""
                                                class="form-control form-control-sm"style="background:lightyellow;color:#000;text-align:center">
                                        </div>
                                        <div class="form-group">
                                            <h6>
                                                طريقة الدفع
                                            </h6>
                                            <input type="text" value="<?php echo e($bill_salse_info->pay_type); ?>" name="" id=""
                                            class="form-control form-control-sm"style="background:lightyellow;color:#000;text-align:center">
                                            
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <h6>
                                                قيمة الضريبة
                                            </h6>
                                            <input type="text" name="" id=""
                                                class="form-control form-control-sm" disabled
                                                style="background:lightyellow;color:#000;text-align:center">
                                        </div>
                                        <div class="form-group">
                                            <h6>
                                                قيمة الخصم
                                            </h6>
                                            <input type="text" name="" id=""
                                                class="form-control form-control-sm" disabled
                                                style="background:lightyellow;color:#000;text-align:center">
                                        </div>
                                        <div class="form-group">
                                            <h6>
                                                المبلغ المسدد
                                            </h6>
                                            <input type="text" value="<?php echo e($bill_salse_info->what_paid); ?>"  name="" id=""
                                                class="form-control form-control-sm" disabled
                                                style="background:lightyellow;color:#000;text-align:center">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <h6>
                                                الإجمالي قبل الخصم
                                            </h6>
                                            <input type="text" name="" id=""
                                                class="form-control form-control-sm" disabled
                                                style="background:lightyellow;color:#fff;text-align:center">
                                        </div>
                                        <div class="form-group">
                                            <h6>
                                                الإجمالي النهائي
                                            </h6>
                                            <input type="text" value="<?php echo e($bill_salse_info->total); ?>" name="" id="" 
                                                class="form-control form-control-sm" disabled
                                                style="background:lightyellow;000:#fff;text-align:center">
                                        </div>
                                        <div class="form-group">
                                            <h6>
                                                المبلغ المتبقي تحصيلة
                                            </h6>
                                           
                                            <input type="text"  value="<?php echo e($bill_salse_info->what_not_yet_paid); ?>" name=""  id=""
                                                class="form-control form-control-sm" disabled
                                                style="background:lightyellow;color:#000;text-align:center">
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <h6>
                                                ملاحظات على الفاتورة
                                            </h6>
                                            <input type="text" name="" id=""
                                                style="background: lightyellow" class="form-control form-control-sm"
                                                value="<?php echo e($bill_salse_info->note); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div align="center" class="from-group">
                                    <a href="#" id="toastsDefaultSuccess" class="btn btn-warning btn-sm">طباعة
                                        الفاتورة
                                        <i class="fa fa-print"></i></a>
                                    <a href="<?php echo e(route('Salse')); ?>" class="btn btn-primary btn-sm">
                                         رجوع لفواتير المبيعات
                                        <i class="fa fa-rowo"></i></a>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Salse/edit.blade.php ENDPATH**/ ?>