

<?php $__env->startSection('title'); ?>
    Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">الحسابات والنقدية</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Cat')); ?>">الحسابات المالية</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">

                            <?php echo e(__('أنواع الحسابات المالية')); ?></div>
                        </h4>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="col-sm-12">
                            <table id="dataTable" class="table table-bordered table-hover " aria-describedby="example1_info">
                                <thead>
                                    <tr>
                                        <th>اسم الحساب المالي</th>
                                        <th> حالة الحساب المالي</th>
                                        <th> Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $mony_acconunt_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($item->account_name); ?>

                                            </td>
                                            <td>
                                               <?php if(($item->status)==1): ?>
                                                   الحساب مفعل
                                                   <?php else: ?>
                                                   الحساب ليس مفعل
                                               <?php endif; ?> 
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('accounts_type.edit', $item->id)); ?>" id="cat_edit"
                                                    class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a>
                                              
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card-body -->


                    
                    <div class="modal fade" id="modal-cat_edit">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Default Modal</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('Category.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">اسم الحساب المالي</label>
                                                    
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">وصف الحساب المالي</label>
                                                    
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <button type="button" class="btn btn-primary"
                                                    data-dismiss="modal">إغلاق</button>
                                                <button type="submit" class="btn btn-primary btn-sm">تأكيد</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Account_Mony_Type/index.blade.php ENDPATH**/ ?>