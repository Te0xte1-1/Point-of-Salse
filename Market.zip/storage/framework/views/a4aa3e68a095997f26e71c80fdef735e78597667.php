<div class="table-responsive">
<table id="dataTable" class="table table-bordered table-stripped table-hover">
    <thead class="table table-secondary">
        <th>كود الفاتــــــورة</th>
        <th>اسم الصنف</th>
        <th>كمية الصنف</th>
        <th>سعر شراء الصنف</th>
        <th>إجمالي </th>
        <th>اكشن</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $get_items_from_order_bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->order_id); ?></td>
                <td><?php echo e($item->item_id); ?></td>
                <td><?php echo e($item->item_qty); ?></td>
                <td><?php echo e($item->unit_price); ?></td>
                <td id="td_total_price"><?php echo e($item->total_price); ?></td>
                <td>
                    <?php if($get_order_bill->is_approved == 0): ?>
                        <a href="#"class="btn btn-warning btn-sm" data-id="<?php echo e($item->id); ?>"
                            value="<?php echo e($item->id); ?>" id="edit_item_after_add">
                            <i class="fas fa-edit"></i>
                            <a href="#" id="delete_item" data-order_id="<?php echo e($item->order_id); ?>"
                                data-delete_id="<?php echo e($item->id); ?>" value="" class="btn btn-danger btn-sm m-1">
                                <i class="fa fa-trash"></i>
                            </a>
                        <?php else: ?>
                            الفاتــــــورة مغلقة ولا يمكن التعديل عليها
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
</div><?php /**PATH C:\xampp\htdocs\Market\resources\views/Purshace/load_purshace/items_added_done.blade.php ENDPATH**/ ?>