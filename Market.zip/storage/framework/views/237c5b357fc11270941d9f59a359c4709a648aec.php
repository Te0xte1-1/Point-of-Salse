

<?php $__env->startSection('title'); ?>
    Suppliers
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">ضبط المخازن</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Cat')); ?>">الأقسام</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('الــمـــوردون')); ?>

                        </h4>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">

                            <a href="<?php echo e(route('Suppliers.create')); ?>" class="btn btn-primary btn-sm">
                                اضافه مورد جديد
                            </a>

                        </div>


                        <hr>
                        <div class="col-sm-12">
                            <table id="dataTable" class="table table-bordered table-striped " aria-describedby="example1_info">
                                <thead>
                                    <tr>
                                        <th>اسم المورد</th>
                                        <th>وصف المورد</th>

                                        <th>
                                            Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $Suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($item->sup_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->cat_description); ?>

                                            </td>
                                            <td>
                                                <a href="Cat/edit/<?php echo e($item->cat_description); ?>" id="cat_edit"
                                                    class="btn btn-info btn-sm" data-toggle="modal"
                                                    data-target="#modal-cat_edit">Edit</a>
                                                <a href="Cat/delete/<?php echo e($item->cat_description); ?>" id="cat_delete"
                                                    class="btn btn-danger btn-sm">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card-body -->



                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Suppliers/index.blade.php ENDPATH**/ ?>