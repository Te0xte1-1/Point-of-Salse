<form action="<?php echo e(route('Purshace.approve')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">
         <input type="hidden" name="auto_serial" value="<?php echo e($get_order_bill->auto_serial); ?>">
            <div class="form-group">
                <label for="" class="label_approve">
                    إجمالي أصناف الفاتــــــورة
                </label>
                <input type="text" disabled value="<?php echo e($get_order_bill->total_cost); ?>"
                    class="form-control form-control-sm" name="total_items_cost" id="total_items_cost">
                <input type="hidden" value="<?php echo e($get_order_bill->total_cost); ?>" class="form-control form-control-sm"
                    name="total_items_cost_hidden" id="total_items_cost_hidden">
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    قيمة الضريبة المضافة
                </label>
                <input type="number" disabled class="form-control form-control-sm" name="tax_value_added"
                    id="tax_value_added">
                <input type="hidden" class="form-control form-control-sm" name="tax_value_added_hidden"
                    id="tax_value_added_hidden">
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    نوع الخصم إن وجد
                </label>
                <select name="discount_type" id="discount_type" class="form-control form-control-sm">
                    <option value="0">-- لا يوجد خصم --</option>
                    <option value="1">نسبة مئوية</option>
                    <option value="2">قيمة يدوية</option>
                </select>
            </div>

            <div class="form-group">
                <label for="" class="label_approve">
                    قيمة الخصم
                </label>
                <input type="number" disabled class="form-control form-control-sm" name="disocunt_value_added"
                    id="disocunt_value_added">
                <input type="hidden" class="form-control form-control-sm" name="disocunt_value_added_hidden"
                    id="disocunt_value_added_hidden">
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    خزنة الصرف
                </label>
                <select name="treasures_id" id="treasures_id" class="form-control form-control-sm">
                    <option value="0">-- اختر الخزينة --</option>
                    <?php $__currentLoopData = $treasures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->treasures_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    طريقة الدفع
                </label>
                <select name="pay_type" id="pay_type" class="form-control form-control-sm">
                    <option value="0">-- اختر طريقة الدفع --</option>
                    <option value="1">كاش</option>
                    <option value="2">أجل</option>
                </select>
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    المتبقي للمورد
                </label>
                <input type="text" disabled class="form-control form-control-sm" name="remain_to_supplier"
                    id="remain_to_supplier">
                <input type="hidden" class="form-control form-control-sm" name="remain_to_supplier_hidden"
                    id="remain_to_supplier_hidden">
            </div>

        </div>
        <div class="col-md-6">

            <div class="form-group">
                <label for="" class="label_approve">
                    نسبة ضريبة القيمة المضافة
                </label>
                <input type="number" value="0" min="0" class="form-control form-control-sm"
                    name="tax_value" id="tax_value">
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    قيمة الإجمالي بعد الضريبة
                </label>
                <input type="text" disabled class="form-control form-control-sm" name="total_before_discount"
                    id="total_before_discount">
                <input type="hidden" class="form-control form-control-sm" name="total_before_discount_hidden"
                    id="total_before_discount_hidden">
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    نسبة الخصم
                </label>
                <input type="number" value="0" min="0" class="form-control form-control-sm"
                    name="discount_value" id="discount_value">
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    الإجمالي النهائي بعد الخصم وبعد الضريبة
                </label>
                <input type="text" disabled class="form-control form-control-sm"
                    value="<?php echo e($get_order_bill->total_cost); ?>" name="total_after_all" id="total_after_all">
                <input type="hidden" class="form-control form-control-sm" value="<?php echo e($get_order_bill->total_cost); ?>"
                    name="total_after_all_hidden" id="total_after_all_hidden">
            </div>

            <div class="form-group">
                <label for="" class="label_approve">
                    الرصيد المتاح بالخزينة
                </label>
                <input type="text" disabled class="form-control form-control-sm" name="available_balance"
                    id="available_balance">
            </div>
            <div class="form-group">
                <label for="" class="label_approve">
                    المبلغ المدفوع للمورد الاَن
                </label>
                <input type="text" class="form-control form-control-sm" name="what_paid_now" id="what_paid_now">
            </div>

        </div>
    </div>
    <button type="submit" class="btn btn-danger btn-sm "style="margin-left:500px">
        إكمال العملية
        <i class="fa fa-print"></i>
    </button>
    <span style="background: #050b29;padding: 13px;color: #fff;margin-left: 990px;font-size:20px">15,000.00
    </span>
</form>


<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<script>
    $(document).ready(function() {

        $('body').on('keyup change', '#tax_value', function(e) {

            if ($(this).val() == "") {
                alert("يجب ان تكون القيمة على الأقل 0");
                $(this).val('0');
                return false;
            } else {

                Calculate_bill();
            }
        }); // Tax Operations

        $('body').on('keyup change', '#discount_value', function(e) {
            if ($(this).val() == "") {
                alert("يجب ان تكون القيمة على الأقل 0");
                $(this).val('0');
                return false;
            } else {

                Calculate_bill();
            }
        }); // Discount Operations

        $('body').on('keyup change', '#what_paid_now', function(e) {

            var what_paid_now = $(this).val();
            var total_after_all = $('#total_after_all').val();
            what_paid_now = parseFloat(what_paid_now);
            total_after_all = parseFloat(total_after_all);

            var operation = what_paid_now -= total_after_all;
            $('#remain_to_supplier').val(operation);


        }); // what_paid_now

        $('body').on('change', '#treasures_id', function(e) {
            var treasures_id = $(this).val();
            $.ajax({
                method: 'post',
                url: "<?php echo e(route('Purshace.get_treasures_data')); ?>",
                dataType: "json",
                cach: false,
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    treasures_id: treasures_id
                },
                success: function(data) {
                    $('#available_balance').val(data);
                }


            });
        }); // Bring Treasures Balance By ID 

        $('body').on('change', '#pay_type', function(e) {
            var pay_type = $(this).val();
            var total_after_all = $('#total_after_all').val();
            if (pay_type == 1) {
                $('#what_paid_now').val(total_after_all);
                $('#what_paid_now').attr('readonly', true);
                $('#remain_to_supplier').val(0);


            } else {
                $('#what_paid_now').val(0);
                $('#what_paid_now').attr('readonly', false);
                $('#remain_to_supplier').val(total_after_all);
            }
        }); // Pay Type Change Supplier balance  Treasures Balance By ID 


        function Calculate_bill() {
            var tax = $('#tax_value').val();
            var total_items_cost = $('#total_items_cost').val();
            tax = parseFloat(tax);
            total_items_cost = parseFloat(total_items_cost);
            var operation = tax * total_items_cost / 100;
            $('#tax_value_added').val(operation);
            $('#tax_value_added_hidden').val(operation);
            $('#total_before_discount').val(total_items_cost += operation);
            // Tax Calc


            var discount = $('#discount_value').val();
            var total_before_discount = $('#total_before_discount').val();
            discount = parseFloat(discount);
            total_before_discount = parseFloat(total_before_discount);
            var operation = discount * total_before_discount / 100;
            $('#disocunt_value_added').val(operation);
            $('#disocunt_value_added_hidden').val(operation);
            $('#total_after_all').val(total_before_discount -= operation);
            // Discount Calc
        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/load_purshace/prepare_bill_to_complete.blade.php ENDPATH**/ ?>