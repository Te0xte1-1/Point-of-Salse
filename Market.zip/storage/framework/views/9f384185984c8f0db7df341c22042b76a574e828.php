

<?php $__env->startSection('title'); ?>
    الحركات النقدية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">الحسابات و النقدية</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Mony_Type_Move')); ?>">الحركات النقدية</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center"><?php echo e(__('الحركات النقدية')); ?>

                        </h4>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="col-sm-12">
                            <table id="dataTable" class="table table-bordered table-striped " aria-describedby="example1_info">
                                <thead>
                                    <tr>
                                        <th>
                                            اسم الحركة النقدية</th>
                                        <th>
                                            وصف الحركة النقدية</th>
                                        <th>
                                            حالة الحساب</th>
                                        <th>
                                            Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $mony_move_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->mony_move_type); ?></td>
                                            <td><?php echo e($item->screen_show); ?></td>
                                            <td>
                                                <?php if($item->status == 1): ?>
                                                    مفعل
                                                <?php else: ?>
                                                    الحساب متوقف
                                                <?php endif; ?>
                                            </td>
                                            <td><a href="<?php echo e(route('Mony_Type_Move.edit', $item->id)); ?>"
                                                    class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Mony_Move_Type/index.blade.php ENDPATH**/ ?>