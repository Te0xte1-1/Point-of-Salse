

<?php $__env->startSection('content'); ?>
    <style>
        th,
        td {
            text-align: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            padding: 10px;
        }

        .row {
            padding-left: 10px;
            padding-right: 10px;
        }

        h2,
        h6 {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center !important;
        }

        label {
            float: right !important;
            margin-right: 15px;

        }

        .label_approve {
            font-size: 14px;
            font-family: aria;
            color: #000;
            font-weight: bold;
        }
    </style>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            تفاصيل فاتورة مشتريات رقم
                        </h4>
                        <span style="margin-left:160px" class="text-center">

                            ( <?php echo e($bill_info->auto_serial); ?> )
                        </span>
                        <a title="رجوع لصفحة المشتريات" href="<?php echo e(route('Purshace')); ?>" class="text-left"><i
                                class="fa fa-arrow-left"></i></a>
                    </div>

                    

                        <div class="card-body">
                            <table id="dataTable" class="table table-bordered table-hover">
                                <thead class="table table-info">
                                    <tr>
                                        <th>الحقل</th>
                                        <th>القيمة</th>
                                    </tr>
                                </thead>
                                <tbody id="parent_added_done">



                                </tbody>
                            </table>
                            <br>
                            
                        </div>



                        <div class="modal fade" id="modal-xl-add-items">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">

                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="card card-info card-outline">
                                                    <div class="card-header ">
                                                        <b>
                                                            <h5 class="text-center">إضافة أصناف للفاتورة رقم
                                                                (<?php echo e($bill_info->auto_serial); ?>)
                                                            </h5>
                                                        </b>
                                                    </div>
                                                    <!-- /.card-header -->
                                                    <form id="add_item_form">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="card-body">


                                                            <input type="hidden" id="url"
                                                                value="<?php echo e(route('Purshace.add_items_store')); ?>">


                                                            <div id="example2_wrapper"
                                                                class="dataTables_wrapper dt-bootstrap4">
                                                                <div class="row">
                                                                    <div class="col-md-3">
                                                                        <div class="form-group">
                                                                            <h6>
                                                                                <i class="far fa-calendar-alt"></i>
                                                                                التـــاريخ
                                                                            </h6>

                                                                            <input type="date" name="date"
                                                                                value="<?php echo e($bill_info->date); ?>"
                                                                                style="background:rgb(190, 202, 213);color:#fff;text-align:center"
                                                                                class="form-control form-control-sm"
                                                                                id="date">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-3">
                                                                        <div class="form-group">
                                                                            بيانات العميل
                                                                            <input type="text" name=""
                                                                                style="background:rgb(190, 202, 213);color:#fff;text-align:center"
                                                                                class="form-control form-control-sm"
                                                                                id=""value="<?php echo e($bill_info->supplier_id); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-3">
                                                                        <div class="form-group">
                                                                            <h6>رقم الفاتورة <i class="fa fa-barcode"></i>
                                                                            </h6>
                                                                            <input type="text"
                                                                                value="<?php echo e($bill_info->auto_serial); ?>"
                                                                                name="serial"
                                                                                style="background:rgb(190, 202, 213);color:#fff;text-align:center"
                                                                                class="form-control form-control-sm"
                                                                                id="serial">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-3">
                                                                        <div class="form-group">
                                                                            <h6>نوع الفاتورة <i class="fa fa-barcode"></i>
                                                                            </h6>
                                                                            <input type="text" name=""
                                                                                style="background:rgb(190, 202, 213);color:#fff;text-align:center"
                                                                                class="form-control form-control-sm"
                                                                                value="<?php echo e($bill_info->order_pay_type); ?>"
                                                                                id="">
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                                <hr style="border:1px solid #007bff">
                                                                <div class="row">

                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <h6>القسم</h6>

                                                                            <select class="form-control select2"
                                                                                name="cat" id="cat">
                                                                                <option value=""></option>
                                                                                <?php $__currentLoopData = $Categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($category->id); ?>">
                                                                                        <?php echo e($category->cat_name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">

                                                                            <h6 style="text-align: center">الصنف</h6>
                                                                            <select class="form-control form-control"
                                                                                name="pro" id="pro">
                                                                            </select>

                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <h6>بيانات وحدة الصنف</h6>
                                                                            <select class="form-control select2"
                                                                                name="unit" id="unit">
                                                                                <option value=""></option>
                                                                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($unit->id); ?>">
                                                                                        <?php echo e($unit->unit_name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <h6>سعر الوحدة</h6>
                                                                            <input type="number" name="price"
                                                                                class="form-control form-control-sm"
                                                                                id="unit_price">
                                                                            <input type="hidden" id="unit_price"
                                                                                name="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <h6>الكمية المستلمة</h6>
                                                                            <input type="number" name="qty"
                                                                                class="form-control form-control-sm"
                                                                                id="qty">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <h6>الإجمالي</h6>
                                                                            <input type="text" name="subtotal" disabled
                                                                                class="form-control form-control-sm"
                                                                                id="price_invoice">
                                                                            <input type="hidden" id="total_cost"
                                                                                name="">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <h6>تاريخ الإنتاج</h6>
                                                                            <input type="date" name="creation_product"
                                                                                class="form-control form-control-sm"
                                                                                id="creation_product">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <h6>تاريخ الإنتاج</h6>
                                                                            <input type="date"
                                                                                name="expiration_product"
                                                                                class="form-control form-control-sm"
                                                                                id="expiration_product">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group text-center">
                                                                            <button type="button"
                                                                                class="btn btn-danger btn-sm add_new_row mt-4"
                                                                                value="">
                                                                                إضافة الصنف للفاتورة
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>

                                                    <hr style="border:1px solid #007bff">

                                                </div>
                                            </div>
                                            <!-- /.card-body -->
                                        </div>
                                    </div>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                        </div>


                        <div class="modal fade" id="modal-xl-edit_items">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    
                                    <div class="modal-body" id="modal-xl-edit_items_body">

                                    </div>
                                    
                                </div>
                            </div>
                        </div>



                        <div class="modal fade" id="modal-xl_approved_bill">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    <div class="modal-header" style="background: #020e23;color:#fff;">
                                        <a href="#" style="margin-right:500px;color:#fff">إعتـمـاد
                                            الفاتــــــورة
                                            (<?php echo e($bill_info->auto_serial); ?>)
                                        </a>
                                    </div>
                                    <div class="modal-body" id="modal-xl_approved_bill_body">

                                    </div>
                                    <div class="modal-footer" style="background: #020e23;color:#fff;text-align:center;">
                                        <button type="button" data-dismiss="modal"
                                            class="btn btn-light btn-sm">خروج</button>
                                    </div>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <table id="dataTable" class="table table-bordered table-stripped table-hover">
                <thead class="table table-secondary">
                    <th>كود الفاتــــــورة</th>
                    <th>اسم الصنف</th>
                    <th>كمية الصنف</th>
                    <th>سعر شراء الصنف</th>
                    <th>إجمالي </th>
                    <th>اكشن</th>
                </thead>
                <tbody id="items_added_done">
                </tbody>
            </table>

        </div>

        <div class="row justify-content-center">
            <div class="col-md-6 text-center">
                <div class="col-lg-10 col-12">
                    <!-- small box -->
                    <div class="small-box bg-info"
                        style="background: #3d595e !important;color:#fff; max-width: 51.333333%;margin-right: 150px;">
                        <div class="inner">
                            <h3 id="show_total">00,00</h3>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag"></i>
                        </div>
                        <a href="#" class="small-box-footer">إجمالي الفاتــــــورة <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/Adminlte.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            reload_table_parent_data();
            reload_table_data();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var td_total_price = 0;
            $('#td_total_price').each(function() {
                var me = parseInt($(this).val());
                $('#show_total').val(td_total_price += me);
            });

            $('body').on('click', '.add_new_row', function(e) {
                var add_item_form = $('#add_item_form').serialize();
                var url = $('#url').val();
                var serial = $('#serial').val();
                var cat = $('#cat').val();
                var pro = $('#pro').val();
                var unit = $('#unit').val();
                var qty = $('#qty').val();
                var price = $('#unit_price').val();
                var total = $('#total_cost').val();
                var creation_product = $('#creation_product').val();
                var expiration_product = $('#expiration_product').val();

                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('Purshace.add_items_store')); ?>",
                    dataType: "json",
                    cach: false,
                    data: {

                        _token: '<?php echo e(csrf_token()); ?>',
                        serial: serial,
                        cat: cat,
                        pro: pro,
                        unit: unit,
                        qty: qty,
                        price: price,
                        total: total,
                        creation_product: creation_product,
                        expiration_product: expiration_product,

                    },
                    success: function(data) {
                        alert('لقد تمت إضافة الصنف الى الفاتورة بنجاح');
                        var cat = $('#cat').val("");
                        var pro = $('#pro').val("");
                        var unit = $('#unit').val("");
                        var qty = $('#qty').val("");
                        var price = $('#unit_price').val("");
                        var total = $('#total_cost').val("");
                        var total = $('#price_invoice').val("");
                        var creation_product = $('#creation_product').val("");
                        var expiration_product = $('#expiration_product').val("");

                        reload_table_parent_data();
                        reload_table_data();

                    },
                });

            });

            $('body').on('keyup change', '#unit_price,#qty', function(e) {

                get_total_cost();
            });

            function reload_table_parent_data() {
                var serial = $('#serial').val();
                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('Purshace.load_purshace.parent_added_done')); ?>",
                    dataType: "html",
                    cach: false,
                    data: {

                        _token: '<?php echo e(csrf_token()); ?>',
                        serial: serial
                    },
                    success: function(data) {

                        $('#parent_added_done').html(data);
                    }
                });

            } // Get Reload Table Data

            function reload_table_data() {
                var serial = $('#serial').val();
                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('Purshace.load_purshace.items_added_done')); ?>",
                    dataType: "html",
                    cach: false,
                    data: {

                        _token: '<?php echo e(csrf_token()); ?>',
                        serial: serial
                    },
                    success: function(data) {
                        $('#items_added_done').html(data);
                        var parent_total = $('#parent_total').html();
                        $('#show_total').html(parent_total);
                    }
                });

            } // Get Reload Table Data

            function get_total_cost() {

                var unit = $('#unit_price').val();
                var qty = $('#qty').val();
                var total = $('#price_invoice').val(unit * qty);
                var total2 = $('#price_invoice').html(unit * qty);
                var total_cost = $('#total_cost').val(unit * qty);
            } // Get Calculate of Two Arguments Data

            $('body').on('change', '#cat', function(e) {
                var cat_id = $(this).val();
                // alert(cat_id);
                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('load_purshace.load_pro_by_cat_id_in_purshace')); ?>",
                    dataType: "html",
                    data: {

                        _token: '<?php echo e(csrf_token()); ?>',
                        cat_id: cat_id
                    },
                    success: function(data) {
                        $('#pro').html(data);
                    },
                });
            }); // Cat ID To Bring Pro Data
            $('body').on('click', '#modal-xl-edit_items', function() {

                var item_id = $(this).data('id');
                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('Purshace.load_purshace.edit_items_after_added_to_order')); ?>",
                    dataType: "html",
                    cach: false,
                    data: {

                        _token: '<?php echo e(csrf_token()); ?>',
                        item_id: item_id
                    },
                    success: function(data) {
                        $('#modal-xl-edit_items').modal('show');
                        $('#modal-xl-edit_items_body').html(data);
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/add_items.blade.php ENDPATH**/ ?>