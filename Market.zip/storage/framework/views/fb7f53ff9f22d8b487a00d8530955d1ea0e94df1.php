
<?php $__env->startSection('title'); ?>
    Print Invoice Salse A6
<?php $__env->stopSection(); ?>
<style>
    body {
        direction: rtl;
        border: 1px dotted #EEE;

    }

    th,
    td {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        text-align: center !important;
    }

    th {
        font-size: 16px;
        font-weight: bold;
    }

    .get_total {
        text-align: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: brown;
        font-weight: bold;
        font-size: 20px;
    }

    .right_table,
    .up_head {
        display: flex;
        justify-content: space-between
    }

    .invoice-col {
        margin-left: 10px !important;
        border: dashed 1px #000000;
    }

    #foot_hide {
        display: none;
    }

    @media print {
        #foot_hide {
            display: block;

        }

        #prin {
            display: none;
        }

        h6 {
            padding: 20px;
        }
    }
</style>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <br>
            <h4 class="text-center">طباعة الفاتــــــورة</h4>
            <div class="table-responsive">
                <div class="right_table">

                    <table>
                        <tr>
                            <td>التـــاريخ <?php echo e($salse->date); ?></td>
                        </tr>
                        <tr>
                            <td>رقم الفاتــــــورة <?php echo e($salse->serial); ?></td>
                        </tr>
                        <tr>
                            <td>رقم الوردية <?php echo e(1); ?></td>
                        </tr>
                        <tr>
                            <td>اسم العميل
                                <?php if($salse->customer_id == 404): ?>
                                    ( عميل سفري )
                                <?php else: ?>
                                    ( <?php echo e($salse->customer_name); ?> )
                                <?php endif; ?>


                            </td>
                        </tr>
                        <tr>
                            <td>رقم حساب العميل <?php echo e($salse->account_number); ?></td>
                        </tr>
                    </table>
                    <table style="margin-top: -36px;margin-left:100px;font-weight:bold">
                        <tr>
                            <td>
                                شركة
                                <br>
                                [ IP-Magix ]
                                <br>
                                للحلول التقنية
                                المتكاملة
                                <br>
                            </td>
                        </tr>
                    </table>
                    <img src="<?php echo e(asset('images/products/17083351203468.png')); ?>" width="100" height="100" alt="">
                </div>

            </div>
            <hr>
            <div class="up_head text-center">
                <span>زمن الفاتــــــورة : 20-10:10 PM</span>
                <span style="margin-left:100px;">اسم البائع : Administraion </span>
                <span>رقم الوردية : 125</span>
            </div>

            <hr><br><br>
            <table dir="rtl" border="1"
                style="width: 98%;margin-bottom:35px;text-align:center; border:1px solid #ddd4d4 !important"cellcpacing="0"
                cellpadding="1">

                <head style="font-weight:bold;font-size:16px">
                    <tr>
                        <th colspan="5"style="background-color:#9d8d8dd9; font-weight:bold">تفاصيل
                            الأصناف
                        </th>
                    </tr>
                    <tr>
                        <th>اسم القسم</th>
                        <th>اسم الصنف</th>
                        <th>الكمية</th>
                        <th>السعر</th>
                        <th>اجمالي الصنف</th>
                    </tr>
                </head>
                <tbody>

                    <?php $__currentLoopData = $salse_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->category_name); ?></td>
                            <td><?php echo e($item->product_name); ?></td>
                            <td><?php echo e($item->qty); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td><?php echo e($item->subtotal); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="5" style="background-color:#ddd;">إجمالي الفاتورة
                            (<?php echo e($salse->total); ?>) جنية فقط لا غير</td>
                    </tr>
                </tbody>
            </table>

            <hr>
            <br>
            <div class="table-responsive">
                <table dir="rtl" border="1"
                    style="width: 98%;margin:0 auto;float: right;text-align:center; border:1px solid #ddd4d4"cellcpacing="0"
                    cellpadding="1">
                    <tr>
                        <th colspan="5" style="background-color:#ddd;">التفاصيل المالية</th>
                    </tr>
                    <tr>
                        <th>طريقة السداد </th>
                        <th>المدفوع من الفاتــــــورة</th>
                        <th> المتبقي من الفاتــــــورة</th>
                        <th>اجمالي الخصم </th>
                        <th>اجمالي قيمة الفاتــــــورة </th>
                    </tr>
                    <tr>
                        <td>
                            <?php if($salse->pay_type == 1): ?>
                                كاش
                            <?php elseif($salse->pay_type == 2): ?>
                                أجل
                            <?php else: ?>
                                جزء كاش وجزء أجل
                            <?php endif; ?>

                        </td>
                        <td><?php echo e($salse->what_paid); ?></td>
                        <td><?php echo e($salse->what_not_yet_paid); ?></td>
                        <td><?php echo e($salse->discount_amount); ?></td>
                        <td><?php echo e($salse->total); ?></td>
                    </tr>

                </table>
            </div>


            <span class="text-center" style="position: fixed;bottom:50px;left:480px;" id="foot_hide">
                شكرا لزيارتكم الجميلة
            </span>
            <span style="position:fixed;bottom:50px;left:30px;" id="foot_hide">0114700220</span>
            <span style="position:fixed;bottom:50px;right:30px;" id="foot_hide">0114700220</span>
        </div>

    </div>
</div>
</div>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<!-- AdminLTE App -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<!-- AdminLTE App -->
<script src="<?php echo e(asset('js/Adminlte.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        window.print();

    });
</script>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Prints/Salse/Done_Print_A4.blade.php ENDPATH**/ ?>