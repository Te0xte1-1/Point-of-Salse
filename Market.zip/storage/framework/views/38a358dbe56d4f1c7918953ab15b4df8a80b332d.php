
<?php $__env->startSection('title'); ?>
    عرض بيانات حساب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        th,
        td {
            text-align: center;
        }

        .container {
            padding: 10px;
        }

        .row {
            padding-left: 10px;
            padding-right: 10px;
        }

        h2 {
            text-align: center !important;
        }
    </style>

    <div class="container-fluid">

        <div class="card card-primary card-outline">
            <div class="card-header text-right">
                <h6>
                    صفحة عرض بيانات حساب مالي
                    <i class="fas fa-user"></i>
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-body">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <input type="hidden" class="form-control form-control-sm"
                                                value="<?php echo e($acc_data->account_type); ?>" name="id">
                                            <label >اسم صاحب الحساب</label>
                                            <input type="text" class="form-control form-control-sm"
                                                value="<?php echo e($acc_data->is_parent); ?>" name="cat_name">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label >وصف صاحب الحساب</label>
                                            <input type="text" class="form-control form-control-sm"
                                                value="<?php echo e($acc_data->parrent_account_number); ?>" name="cat_description">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label >حالة صاحب الحساب</label>
                                            <select class="form-control form-control-sm" name="status"
                                                placeholder=" حالة الحساب ">
                                                <option value="<?php echo e($acc_data->name); ?>">مفعل</option>
                                                <option value="0">متوقف</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <input type="hidden" class="form-control form-control-sm"
                                                value="<?php echo e($acc_data->account_number); ?>" name="id">
                                            <label >اسم صاحب الحساب</label>
                                            <input type="text" class="form-control form-control-sm"
                                                value="<?php echo e($acc_data->is_archived); ?>" name="cat_name">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label >وصف صاحب الحساب</label>
                                            <input type="text" class="form-control form-control-sm"
                                                value="<?php echo e($acc_data->note); ?>" name="cat_description">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="">حالة صاحب الحساب</label>
                                            <select class="form-control form-control-sm" name="status"
                                                placeholder=" حالة الحساب ">
                                                <option value="<?php echo e($acc_data->status); ?>">مفعل</option>
                                                <option value="0">متوقف</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="table-responsive">
                            <table id="dataTable" class="table table-bordered table-stripped table-hover">
                                <thead class="table table-success">
                                    <th>#</th>
                                    <th>رقم الحساب</th>
                                    <th>رصيد أول المده</th>
                                    <th>رصيد الحساب الحالي</th>
                                    <th>اسم صاحب الحساب</th>
                                    <th>اعتماد الفاتـــورة</th>
                                    <th>اكشن</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <?php echo e($acc_data->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($acc_data->account_number); ?>

                                        </td>
                                        <td>
                                            <?php echo e($acc_data->start_balance_status); ?>

                                        </td>
                                        <td>
                                            <?php echo e($acc_data->current_balance); ?>

                                        </td>
                                        <td>
                                            <?php echo e($acc_data->start_balance); ?>

                                        </td>
                                        <td>
                                            <?php echo e($acc_data->start_balance); ?>

                                        </td>
                                        <td>
                                            <?php echo e($acc_data->note); ?>

                                        </td>
                                    </tr>

                                </tbody>
                            </table>

                            
                            
                            

                        </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- /.card -->
    </div>
    </div>
    </div>


    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/Adminlte.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {


            $('.add_row').click(function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                var cat_id = $(this).data('cat');
                var cat_name = $(this).data('cat_name');
                var product_name = $(this).data('product_name');
                var price = $(this).data('price');

                $(this).removeClass('btn-info').addClass('btn-default disabled');
                // alert(id + name + price);
                var $data =
                    `<tr>    
                <td>1</td>
                <td>
                    <label>${cat_name}
                    <input type="hidden" name="gogal" value="" class="total-price"/>
                    <input type="hidden" class="form-control form-control-sm" name="cat[]" value="${ cat_id }"/>
                    </td>
                <td>
                                                    <label>${product_name}
                    <input type="hidden" name="pro[]" class="form-control pro- ${  product_name }" value="${id}"/>
                    </td>
                    <td>
                        <input type="number" oninput="this.value=this.value.replace(/[^0-9]/g,'');"class="form-control form-control-sm" min="1" name="الكمية[]" data-price="${price}" value="" class="form-control product-الكمية" id="الكمية">
                        </td>
                        <td>
                            
                            <label>${price}
                            <input type="hidden"class="form-control form-control-sm" name="price[]" id="product-price"value="${price}"/>
                            </td>
                        <td>
                            <label name="" id="subtotall"/>
                        <input type="hidden"class="form-control form-control-sm" name="sub_total[]" id="subtotal" value="sub_total" />
            
                            </td>
                </form>
                    <td><button class="btn btn-danger btn-sm remove_row"data-id="${id}">-</button></td>
                </tr>`;
                $('#tboody').append($data);

                calc_total();

            }); //End Add Row


            $('body').on('change', '#cat', function(e) {

                var cat_id = $(this).val();
                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('load_pro_by_cat_id_in_salse')); ?>",
                    data: {
                        cat_id: cat_id
                    },
                    success: function(data) {
                        console.log(data);
                    },
                });
            }); // Cat ID To Bring Pro Data


            $('.add_new_row').click(function(e) {
                e.preventDefault();
                alert(3);
            });
            $('body').on('click', '.disabled', function(e) {
                e.preventDefault();
            }); //End Disabled Click

            $('body').on('click', '.remove_row', function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                $('#product-' + id).removeClass('btn-default disabled').addClass('btn-info');
                $(this).closest('tr').remove();
                calc_total();

            }); // End Remove Row

            $('body').on('keyup change', '#الكمية', function() {
                var الكمية = parseInt($(this).val());
                var unitprice = $(this).data('price');
                $(this).closest('tr').find('#subtotal').val(الكمية * unitprice);
                $(this).closest('tr').find('#subtotall').html(الكمية * unitprice);
                calc_total();
            }); //End الكمية

            function calc_total() {
                var price = 0;
                $('#tboody #subtotall').each(function() {

                    price += parseInt($(this).html());
                });
                if (price > 0) {
                    $('#order-print').removeClass('btn-info disabled').addClass('btn-info');
                } else {
                    $('#order-print').addClass('btn-info disabled');
                }
                $('.total-price').html(price);
                $('.total-price').val(price);
            } // End Calc Total

            /////////////////////////////////////
            $('#toastsDefaultSuccess').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-success',
                    title: 'Purshace Invoice',
                    subtitle: 'Subtitle',
                    body: 'Your Purshace Has Been Successfully Completed .'
                })
            });

            // toastr

            /////////////////////////////////////

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Account_Tree/show.blade.php ENDPATH**/ ?>