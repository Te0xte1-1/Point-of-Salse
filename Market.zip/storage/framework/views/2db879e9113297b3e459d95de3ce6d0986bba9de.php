
<?php $__env->startSection('title'); ?>
    Settings
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
       
        <div class="row">
            <div class="col-md-12">

                <!-- Profile Image -->
                <div class="card card-primary card-outline">
                    <div class="card-body box-profile">
                        <div class="text-center">

                            <h3 class="profile-username text-center">إسم الشركه</h3>
                            <p class="text-muted text-center">Software Engineer</p>
                            <img class="" width="150px" height="100px" src="<?php echo e(asset('img/photo4.jpg')); ?>">
                        </div>
                        <br>

                        <ul class="list-group list-group-unbordered mb-3">
                            <li class="list-group-item">
                                <a class="">شارع عبدالله الطيب</a>
                                <b class="float-right">مقر الشركة</b>
                            </li>
                            <li class="list-group-item">
                                <a class="">+249114700220</a>
                                <b class="float-right">رقم هاتف الشركة</b>
                            </li>
                            <li class="list-group-item">
                                <a class="">IP-Magix@hotmail.com</a>
                                <b class="float-right">إيميل الشركة</b>
                            </li>

                        </ul>

                        <a href="<?php echo e(route('Settings.edit')); ?>" class="btn btn-primary btn-block"><b>تعديل البيانات</b></a>
                    </div>
                    <!-- /.card-body -->
                </div>

            </div>

        </div>
        <!-- /.row -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/settings/index.blade.php ENDPATH**/ ?>