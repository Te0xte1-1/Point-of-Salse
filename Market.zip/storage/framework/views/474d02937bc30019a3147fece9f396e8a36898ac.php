<?php if(!empty($salse_detailse2)): ?>
    <?php $__currentLoopData = $salse_detailse2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <input type="hidden" name="total_cost_item[]" id="total_cost_item" value="<?php echo e($item->subtotal); ?>">
                <?php echo e($item->cat_name); ?>

            </td>
            <td><?php echo e($item->product_name); ?>

            </td>
            <td id="unit_table"><?php echo e($item->unit_name); ?>

            </td>
            <td id="qty_table"><?php echo e($item->qty); ?>

            </td>
            <td id="price_table"><?php echo e($item->price); ?>

            </td>
            <td id="subtotall_invoice_input"><?php echo e($item->subtotal); ?>

            </td>
            <td><button id="remove_edit_bill" data-id="<?php echo e($item->id); ?>" class="btn btn-danger btn-sm"><i
                        class="fa fa-trash"></i></button></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <tr>
        <td colspan="7" class="alert alert-danger">لا توجد داتا</td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Market\resources\views/Salse/load_salse_edit/reload_items_in_edit_bill.blade.php ENDPATH**/ ?>