<?php echo e($data); ?>

 
 
<?php /**PATH C:\xampp\htdocs\myposs\resources\views/Salse/load_salse/load_table_added.blade.php ENDPATH**/ ?>