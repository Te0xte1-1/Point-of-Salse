

<?php $__env->startSection('title'); ?>
    Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">الحسابات والنقدية</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Cat')); ?>">دليل الحسابات المالي</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">

                            <?php echo e(__('جميع الحسابات المالية')); ?>

                        </h4>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <a href="<?php echo e(route('Accounts.create')); ?>" class=" btn btn-outline-primary btn-sm"
                                style="margin-right: 15px">
                                اضافه حساب مالي
                                <i class="fa fa-plus"></i>
                            </a>
                        </div>
                    <br>
                        <div class="col-sm-12">
                            <table id="dataTable" class="table table-bordered table-stripped table-hover">
                                <thead class="table table-secondary">
                                    <th>
                                        اسم الحساب</th>
                                    <th>
                                        نوع الحساب</th>
                                    <th>هل الحساب أب</th>
                                    <th>
                                        رقم الحساب المالي</th>
                                    <th>
                                        حالة رصيد الحساب أول المدة</th>
                                    <th>
                                        عرض تفاصيل الحساب</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->account_type); ?></td>
                                            <td>
                                            <?php if($item->is_parent == 1): ?>
                                             نعم الحساب أب   
                                            <?php else: ?>
                                                لا
                                            <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->account_number); ?></td>
                                            <td>
                                                <?php if($item->start_balance_status == 1): ?>
                                                     دائن
                                                <?php elseif($item->start_balance_status == 2): ?>
                                                     مدين
                                                <?php elseif($item->start_balance_status == 3): ?>
                                                 متزن
                                                <?php else: ?>

                                                    
                                                <?php endif; ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('Accounts.show',$item->id)); ?>"><i class="fa fa-info"></i></a>

                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card-body -->


                    
                    <div class="modal fade" id="modal-cat_edit">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Default Modal</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('Category.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="card-body">

                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <button type="button" class="btn btn-primary"
                                                    data-dismiss="modal">إغلاق</button>
                                                <button type="submit" class="btn btn-primary btn-sm">تأكيد</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Account_Tree/index.blade.php ENDPATH**/ ?>