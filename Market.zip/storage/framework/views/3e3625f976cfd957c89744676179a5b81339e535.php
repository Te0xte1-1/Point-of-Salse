

<?php $__env->startSection('title'); ?>
    الترحيل بين المخازن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        body {
            /* font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; */
        }h6{
            text-align: center;
            font-size: 14px;
        }.custom-file-input {
    position: relative;
    z-index: 2;
    width: 100%;
    height: calc(2.25rem + 2px);
    margin: 0;
    overflow: hidden;
    opacity: 0;
}
    </style>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">ضبط المخازن</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('first_insert')); ?>">بضاعه أول المدة</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            بضاعه أول المدة
                        </h4>
                    </div>
                    <div class="card-body">
                        <hr>
                        <form action="<?php echo e(route('first_insert.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>قسم المنتج</h6>
                                        <select name="cat_id" id="cat_id" class="form-control form-control-sm">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->cat_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <h6>الرقم التسلسلي للصنف</h6>
                                        <input type="text" class="form-control form-control-sm" name="serial" id="serial">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>اسم الصنف</h6>
                                        <input type="text" name="item" id="item" class="form-control form-control-sm">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <h6>الكمية</h6>
                                        <input type="number" class="form-control form-control-sm" name="qty" id="qty">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <h6>حد الطلب</h6>
                                        <input type="text" class="form-control form-control-sm" name="risk" id="risk">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>سعر الشراء</h6>
                                        <input type="text" class="form-control form-control-sm" name="purshace_price" id="purshace_price">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>سعر البيع</h6>
                                        <input type="text" class="form-control form-control-sm" name="qty" id="qty">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>تاريخ الإنتاج</h6>
                                        <input type="date" class="form-control form-control-sm" name="creation_date" id="creation_date">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <h6>تاريخ إنتهاء الصلاحية</h6>
                                        <input type="date" class="form-control form-control-sm" name="expiration_date" id="expiration_date">
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <h4 class="text-center">الملاحـــظــــات</h4>
                                    <input type="text" style="background:lightyellow" class="form-control form-control-sm" name="note"
                                        id="note">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <h4 class="text-center">صورة الصنف</h4>
                                    <div class="input-group">
                                        <div class="custom-file">
                                          <input type="file" class="custom-file-input" id="pic" name="pic">
                                          <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                        </div>
                                       
                                      </div>
                                </div>
                                <div align="center">
                                    <button class="btn btn-success btn-sm" style="background: #0f2e55; color:#fff; font-family:Arial, Helvetica, sans-serif">إضافة البضاعه</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/first_insert/index.blade.php ENDPATH**/ ?>