<div class="row">
    <div class="col-md-12">
        <div class="card card-warning" style="background-color: #3D3D3D3D;">
            <div class="card-header">
                <b>
                    <h5 class="text-center">تحديث أصناف في الفاتورة رقم
                        (<?php echo e($bill_info->auto_serial); ?>)
                    </h5>
                </b>
            </div>
            <!-- /.card-header -->
            <form id="add_item_form">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <h6>القسم</h6>

                                    <select class="form-control select2" name="cat" id="cat">
                                    
                                        <option value="<?php echo e($bill_info->cat_id); ?>"><?php echo e($bill_info->cat_id); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">

                                    <h6 style="text-align: center">الصنف</h6>
                                    <select class="form-control form-control" name="pro" id="pro">
                                        <option value="<?php echo e($bill_info->item_id); ?>"><?php echo e($bill_info->item_id); ?></option>
                                    </select>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <h6>بيانات وحدة الصنف</h6>
                                    <select class="form-control select2" name="unit" id="unit">
                                        <option value="<?php echo e($bill_info->item_qty); ?>"><?php echo e($bill_info->unit_id); ?></option>
                                        
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <h6>سعر الوحدة</h6>
                                    <input type="text" value="<?php echo e($bill_info->unit_price); ?>" name="price" class="form-control form-control-sm"
                                        id="unit_price">
                                    <input type="hidden" id="unit_price" name="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <h6>الكمية المستلمة</h6>
                                    <input type="number" value="<?php echo e($bill_info->item_qty); ?>" name="qty" class="form-control form-control-sm"
                                        id="qty">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <h6>الإجمالي</h6>
                                    <input type="text" name="subtotal" value="<?php echo e($bill_info->total_price); ?>" disabled class="form-control form-control-sm"
                                        id="price_invoice">
                                    <input type="hidden" id="total_cost" name="">
                                </div>
                            </div>
                        </div>

                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group text-center">
                                    <button type="button" class="btn btn-primary btn-sm update_row mt-4"
                                        value="">
                                        تحديث الصنف المضاف للفاتورة
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            <hr style="border:1px solid  #3D3D3D3D;">
        </div>
    </div>
    <!-- /.card-body -->
</div>
<?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/load_purshace/edit_items_after_added_to_order.blade.php ENDPATH**/ ?>