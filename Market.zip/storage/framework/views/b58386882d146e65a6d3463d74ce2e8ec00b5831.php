

<?php $__env->startSection('content'); ?>
    <style>
        th,
        td,
        label {
            text-align: center !important;
        }
    </style>
    <div class="container-fluid">
<br>
        <div class="row justify-content-center">
            <div class="col-md-12">

                <div class="row">
                    <div class="col-sm-3">
                        <form action="<?php echo e(route('report.purshace_month')); ?>" target="_blank" method="POST">

                            <?php echo csrf_field(); ?>
                            <h6 class="text-center" style="">تقرير مشتريات شهري</h6>
                            <label>من شهر </label>
                            <input type="date" name="purshace_month_from" id="purshace_month_from"
                                value="<?php echo date('Y-m-d') ?>" class="form-control form-control-sm">
                            
                            <label>الى شهر </label>
                            <input type="date" name="purshace_month_to" id="purshace_month_to"
                                value="<?php echo date('Y-m-d') ?>" class="form-control form-control-sm">

                            <input type="submit" class="form-control btn btn-default"
                                style="margin-top:10px ;background:#ddd" value="طباعه التقرير">
                        </form>
                    </div>
                    <div class="col-sm-3">
                        <form action="<?php echo e(route('report.salse_month')); ?>" target="_blank" method="POST">

                            <?php echo csrf_field(); ?>
                            <h6 class="text-center" style="">تقرير مبيعات شهري</h6>
                            <label>من شهر </label>
                            <input type="date" name="salse_month_from" id="salse_month_from"
                                value="<?php echo date('Y-m-d') ?>" class="form-control form-control-sm">
                            
                            <label>الى شهر </label>
                            <input type="date" name="salse_month_to" id="salse_month_to"
                                value="<?php echo date('Y-m-d') ?>" class="form-control form-control-sm">
                            <input type="submit" class="form-control btn btn-default"
                                style="margin-top:10px ;background:#ddd" value="طباعه التقرير">
                        </form>

                    </div>
                    <div class="col-sm-3">
                        <form action="<?php echo e(route('report.risk')); ?>" target="_blank" method="POST">

                            <?php echo csrf_field(); ?>
                            <h6 class="text-center" style="">حد الطلب </h6>
                            <label>اختر القسم </label>
                            <select name="risk_cat" id="risk_cat" class="form-control form-control-sm">
                                <option value="0" selected>-- اختر --</option>
                                <?php $__currentLoopData = $data_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->cat_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label>اختر الصنف </label>
                            <select name="risk_item" id="risk_item" class="form-control form-control-sm">
                                <option value="0">-- اختر --</option>

                            </select>
                            <input type="submit" class="form-control btn btn-default"
                                style="margin-top:10px ;background:#ddd" value="طباعه التقرير">
                        </form>
                    </div>
                    <hr>
                    <div class="col-sm-3">
                        <form action="<?php echo e(route('report.shift')); ?>"" target="_blank" method="POST">

                            <?php echo csrf_field(); ?>
                            <h6 class="text-center" style="">تقرير وردية </h6>
                            <label>رقم الوردية </label>
                            <input type="number" oninput="this.value=this.value.replace(/[^0-9]/g,'');" name="shift_date"
                                id="shift_date" class="form-control form-control-sm">
                            <input type="submit" class="form-control btn btn-default"
                                style="margin-top:10px ;background:#ddd" value="طباعه التقرير">
                        </form>
                    </div>
                </div>


                <hr>

            </div>
            
        </div>
    <?php $__env->stopSection(); ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {

            $('body').on('change', '#risk_cat', function(e) {
                get_item_by_cat_id('#risk_cat', '#risk_item');
            }); // Cat ID To Bring Pro Data

            function get_item_by_cat_id(your_cat = null, your_location_to_save = null) {

                var cat_id = $(your_cat).val();
                $.ajax({
                    method: 'post',
                    url: "<?php echo e(route('load_pro_by_cat_id_in_salse')); ?>",
                    dataType: "html",
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        cat_id: cat_id
                    },
                    success: function(data) {
                        $(your_location_to_save).html(data);
                    },

                });

            }

        });
    </script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Report/Report_All.blade.php ENDPATH**/ ?>