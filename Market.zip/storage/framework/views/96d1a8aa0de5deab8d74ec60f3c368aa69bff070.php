

<?php $__env->startSection('title'); ?>
    مراجعه مصروف النقدية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
<div class="container-fluid">
        <div class="card">
            <div class="card-header text-right">

                <h4  class="text-center"> مراجعه عملية صرف رقم (<?php echo e($data->id); ?>)</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
        <table id="dataTable" class="table table-bordered table-stripped table-hover">
            <thead class="table table-secondary">
                <th>كود العملية</th>
                <th>اسم المورد</th>
            </thead>
      
            <tbody id="load_table_index">      
                <tr>
                    <td>رقم الوردية</td>
                    <td><?php echo e($data->shift_code); ?></td>
                </tr>
                <tr>
                    <td>اسم المستخدم</td>
                    <td><?php echo e($data->added_by); ?></td>
                </tr>
                <tr>
                    <td>تاريخ العملية</td>
                    <td><?php echo e($data->date); ?></td>
                </tr>
                <tr>
                    <td>رقم العملية</td>
                    <td id="auto_serial"><?php echo e($data->id); ?></td>
                </tr>
                <tr>
                    <td>نوع العملية</td>
                    <td>
                    صرف مبلغ مالي
                    </td>
                </tr>
                <tr>
                    <td>الحساب المالي</td>
                    <td>
                    <?php echo e($data->account_number); ?>

                    </td>
                </tr>
                <tr>
                    <td>نوع الحركة المالية</td>
                    <td><?php echo e($data->move_type_id); ?></td>
                </tr>
                <tr>
                    <td>الخزينة</td>
                    <td id="parent_total"><?php echo e($data->treasures_id); ?></td>
                </tr>
                <tr>
                    <td>المبلغ</td>
                    <td id="parent_total"><?php echo e($data->money_for_account); ?></td>
                </tr>
                <tr>
                    <td>تفاصييل البيانات</td>
                    <td><?php echo e($data->note); ?></td>
                </tr>
            
            </tbody>
        </table>
    </div>
    </div>
<div class="card-footer">
    <button class="form-control form-control-sm btn btn-success btn-sm">Print</button>
</div>
</div>

</div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Esal_Srf_Mony/show.blade.php ENDPATH**/ ?>