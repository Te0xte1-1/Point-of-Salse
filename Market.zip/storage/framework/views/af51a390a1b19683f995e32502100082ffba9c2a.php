

<?php $__env->startSection('content'); ?>
    <style>
        th,
        td {
            text-align: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            padding: 10px;
        }

        .row {
            padding-left: 10px;
            padding-right: 10px;
        }

        h2,
        h6 {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center !important;
        }

        label {
            float: right !important;
            margin-right: 15px;
        }
    </style>
    <div class="container">
        
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('المشتريات')); ?>

                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="card-header">
                            <p class="text-center">إضافة فاتورة مشتريات جديده</p>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <!-- form start -->
                            <form action="store" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="">كود الفاتورة</label>
                                            <input type="text" class="form-control" 
                                                value="<?php echo e(rand(1, 1000000000)); ?>" name="code_bill" placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="">الــمـــوردون</label>
                                            <select name="supplier_id" class="form-control" id="supplier_id">
                                                <option value="">--</option>
                                                <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->sup_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="">نوع الفاتــــــورة</label>
                                            <select name="pay_type" id="pay_type" class="form-control">
                                                <option value="">--</option>
                                                <option value="1">أجل</option>
                                                <option value="2">كاش</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="">بيانات المخازن</label>
                                            <select name="store_id" id="store_id" class="form-control">
                                                <option value="">--</option>
                                                <?php $__currentLoopData = $Stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->stock_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="">الملاحظـــات</label>
                                            <input type="text" class="form-control" name="note" placeholder="">
                                        </div>
                                    </div>
                                </div>
                                <div id="do" style="margin-left:450px;">
                                    <a href="<?php echo e(route('Purshace')); ?>" id="close_bill" class="btn-danger btn-sm text-center"
                                        value="">إلغاء الفاتــــــورة</a>
                                    <button type="submit" class="btn-success btn-sm" value="">إكمال العملية</button>
                                </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/Purshace/create.blade.php ENDPATH**/ ?>