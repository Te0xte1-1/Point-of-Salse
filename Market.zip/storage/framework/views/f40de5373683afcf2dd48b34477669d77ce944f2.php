

<?php $__env->startSection('title'); ?>
    Stock
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">

            <li class="breadcrumb-item active">ضبط المخازن</li>
            </li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('Stock')); ?>">المخازن</a></li>
        </ol>
        <div class="row justify-content-left">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h4 class="text-center">
                            <?php echo e(__('المخازن')); ?>

                        </h4>
                        </div>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="dt-buttons btn-group flex-wrap">
                                    <a href="#" class="btn btn-primary btn-sm" style="margin-left:370px;" data-toggle="modal"
                                    data-target="#modal-default">
                                    إضافة مخزن جديد
                            </a>

                                    <div class="modal fade" id="modal-default">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h6 class="modal-title">نافذة لإضافة البيانات الجديدة</h6>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('Stock.store')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="card-body">
                                                            <div class="form-group">
                                                                <label for="">اسم المخزن</label>
                                                                <input type="text" class="form-control" name="stock_name"
                                                                    id="">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="">مكان المخزن</label>
                                                                <input type="text" class="form-control"
                                                                    name="stock_desc" id="">
                                                            </div>
                                                        </div>

                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">Close</button>
                                                            <button type="submit"
                                                                class="btn btn-primary btn-sm">تأكيد</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                                    </div>
                                    <!-- /.modal -->
                                </div>
                            </div>

                        </div>
                        <hr>
                        <div class="col-sm-12">
                            <table id="dataTable" class="table table-bordered table-striped " aria-describedby="example1_info">
                                <thead>
                                    <tr>
                                        <th>
                                            اسم المخزن</th>
                                        <th >
                                            وصف المخزن</th>
                                        <th >
                                            مراجعه الأصــنــاف داخل المخزن</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $Stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td>
                                            <?php echo e($item->stock_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->stock_location); ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('Stock.Show',$item->id)); ?>"><i class="fa fa-edit"></i></a>
                                            </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card-body -->


                    
                    <div class="modal fade" id="modal-cat_edit">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Default Modal</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('Stock.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="card-body">
                                               
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <button type="button" class="btn btn-default"
                                                    data-dismiss="modal">إغلاق</button>
                                                <button type="submit" class="btn btn-primary btn-sm">تأكيد</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myposs\resources\views/stock/index.blade.php ENDPATH**/ ?>